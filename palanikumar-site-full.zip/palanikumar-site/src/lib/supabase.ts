/**
 * Minimal Supabase Auth (GoTrue) client over fetch — server-side only.
 * Credentials are verified by Supabase Auth; admin rights come from the `admin_users` allow-list table.
 */
const url = () => (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const anon = () => process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
const service = () => process.env.SUPABASE_SERVICE_ROLE_KEY || '';

export const supabaseAuthEnabled = () => !!(url() && anon());

export type SbLogin = { ok: true; id: string; email: string } | { ok: false; reason: 'invalid' | 'unavailable' };

export async function supabasePasswordLogin(email: string, password: string): Promise<SbLogin> {
  try {
    const r = await fetch(`${url()}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { apikey: anon(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      cache: 'no-store',
    });
    if (r.status === 400 || r.status === 401 || r.status === 422) return { ok: false, reason: 'invalid' };
    if (!r.ok) return { ok: false, reason: 'unavailable' };
    const d = await r.json();
    const u = d?.user;
    if (!u?.id || !u?.email) return { ok: false, reason: 'invalid' };
    // Revoke the Supabase-side session immediately: this site issues its own short-lived session cookie.
    fetch(`${url()}/auth/v1/logout`, { method: 'POST', headers: { apikey: anon(), Authorization: `Bearer ${d.access_token}` } }).catch(() => {});
    return { ok: true, id: String(u.id), email: String(u.email).toLowerCase() };
  } catch {
    return { ok: false, reason: 'unavailable' };
  }
}

/** Creates (or resets the password of) a Supabase Auth user. Needs the service-role key — run from a trusted machine only. */
export async function supabaseUpsertUser(email: string, password: string): Promise<'created' | 'updated'> {
  const key = service();
  if (!url() || !key) throw new Error('SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required to create the admin in Supabase Auth.');
  const h = { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
  const c = await fetch(`${url()}/auth/v1/admin/users`, { method: 'POST', headers: h, body: JSON.stringify({ email, password, email_confirm: true }) });
  if (c.ok) return 'created';
  const body = await c.text();
  if (c.status !== 422 && c.status !== 409) throw new Error(`Supabase refused to create the user (${c.status}): ${body.slice(0, 200)}`);
  // already exists → find it and reset the password
  for (let page = 1; page <= 20; page++) {
    const l = await fetch(`${url()}/auth/v1/admin/users?page=${page}&per_page=200`, { headers: h });
    if (!l.ok) break;
    const d = await l.json();
    const users: any[] = d.users || [];
    const hit = users.find((u) => String(u.email).toLowerCase() === email);
    if (hit) {
      const u = await fetch(`${url()}/auth/v1/admin/users/${hit.id}`, { method: 'PUT', headers: h, body: JSON.stringify({ password, email_confirm: true }) });
      if (!u.ok) throw new Error(`Could not update the existing user (${u.status}).`);
      return 'updated';
    }
    if (users.length < 200) break;
  }
  throw new Error('The user exists in Supabase but could not be located to update.');
}
