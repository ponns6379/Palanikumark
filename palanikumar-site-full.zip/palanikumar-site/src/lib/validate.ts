import { z } from 'zod';
import type { Field, Resource } from './resources';

const SAFE_URL = /^(https?:\/\/[^\s]+|\/(?!\/)[^\s]*)$/;

function fieldSchema(fl: Field): z.ZodTypeAny {
  switch (fl.type) {
    case 'number':
      return z.preprocess((v) => (v === '' || v === null || v === undefined ? null : Number(v)), z.number().finite().nullable());
    case 'bool':
      return z.preprocess((v) => v === true || v === 'true' || v === 'on' || v === 1 || v === '1', z.boolean());
    default: {
      let s = z.string().trim().max(fl.max ?? (fl.type === 'textarea' ? 20000 : 2000));
      let out: z.ZodTypeAny = s;
      if (fl.type === 'url' || fl.type === 'image') out = s.refine((v) => v === '' || SAFE_URL.test(v), 'Must be an http(s) link or a site path starting with /');
      if (fl.type === 'select' && fl.options) out = s.refine((v) => v === '' || fl.options!.includes(v), 'Invalid option');
      if (fl.required) out = (out as z.ZodString).refine((v: string) => v.length > 0, 'This field is required');
      return out;
    }
  }
}

export type ParseResult = { ok: true; data: Record<string, any> } | { ok: false; errors: Record<string, string> };

/** mode "create": all fields are filled (defaults applied). mode "update": only provided keys are validated. */
export function parseInput(res: Pick<Resource, 'fields' | 'published' | 'sortable'>, input: any, mode: 'create' | 'update'): ParseResult {
  const data: Record<string, any> = {};
  const errors: Record<string, string> = {};
  if (typeof input !== 'object' || input === null) return { ok: false, errors: { _: 'Invalid request body' } };

  for (const fl of res.fields) {
    const has = Object.prototype.hasOwnProperty.call(input, fl.name);
    if (mode === 'update' && !has) continue;
    const raw = has ? input[fl.name] : fl.type === 'bool' ? false : fl.type === 'number' ? null : '';
    const r = fieldSchema(fl).safeParse(raw);
    if (r.success) data[fl.name] = r.data;
    else errors[fl.name] = r.error.issues[0]?.message || 'Invalid value';
  }
  if (res.published && 'published' in input) data.published = input.published === true || input.published === 'true';
  if (res.sortable && 'sort_order' in input) {
    const n = Number(input.sort_order);
    if (Number.isFinite(n)) data.sort_order = Math.trunc(n);
  }
  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, data };
}
