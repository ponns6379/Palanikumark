import { cache } from 'react';
import { one, q, type Row } from './db';
import { LIVE_TABLES } from './resources';

export const getProfile = cache(async (): Promise<Row> => (await one('SELECT * FROM profile WHERE id = 1')) ?? {});

export const getSettings = cache(async (): Promise<Record<string, string>> => {
  const rows = await q<{ key: string; value: string }>('SELECT key, value FROM site_settings');
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
});

export const getSocial = cache(async () => q('SELECT * FROM social_links ORDER BY sort_order, id'));

export async function getStats() {
  const rows = await q('SELECT * FROM stats WHERE published = true ORDER BY sort_order, id');
  const out: Row[] = [];
  for (const r of rows) {
    let value = r.value as string;
    let live = false;
    const m = /^live:([a-z_]+)$/.exec(value);
    if (m && LIVE_TABLES.includes(m[1])) {
      const hasPub = ['scholars', 'awards', 'projects', 'publications', 'patents', 'consultancy', 'news', 'gallery'].includes(m[1]);
      const c = await one<{ c: number }>(`SELECT count(*)::int AS c FROM ${m[1]} ${hasPub ? 'WHERE published = true' : ''}`);
      value = String(c?.c ?? 0);
      live = true;
    }
    out.push({ ...r, value, live });
  }
  return out;
}

export async function getCounts() {
  const tables: [string, string][] = [
    ['publications', 'Publications'], ['patents', 'Patents'], ['awards', 'Awards'], ['projects', 'Funded projects'], ['scholars', 'Ph.D. scholars'],
    ['books', 'Books & chapters'], ['consultancy', 'Consultancy'], ['news', 'News updates'], ['gallery', 'Gallery images'], ['memberships', 'Memberships'], ['editorial_roles', 'Editorial roles'],
  ];
  const out: { key: string; label: string; count: number }[] = [];
  for (const [t, label] of tables) out.push({ key: t, label, count: (await one<{ c: number }>(`SELECT count(*)::int AS c FROM ${t}`))?.c ?? 0 });
  return out;
}

export const pub = (table: string, order: string, where = '', params: any[] = []) =>
  q(`SELECT * FROM ${table} WHERE published = true ${where ? 'AND ' + where : ''} ORDER BY ${order}`, params);
