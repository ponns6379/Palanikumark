import fs from 'node:fs';
import path from 'node:path';
import { buildDDL, buildRLS } from './schema';

export type Row = Record<string, any>;
export interface Driver {
  kind: 'pglite' | 'postgres';
  query: (text: string, params?: any[]) => Promise<Row[]>;
  exec: (text: string) => Promise<void>;
}

const g = globalThis as unknown as { __pkDb?: Promise<Driver> };

async function open(): Promise<Driver> {
  const url = process.env.DATABASE_URL;
  if (url) {
    const postgres = (await import('postgres')).default;
    const local = /@(localhost|127\.0\.0\.1|\[::1\])[:/]/.test(url);
    const ssl = process.env.DATABASE_SSL === 'false' || (local && process.env.DATABASE_SSL !== 'true') ? false : 'require';
    const sql = postgres(url, { max: 5, ssl, prepare: false, idle_timeout: 20, connect_timeout: 15 });
    return {
      kind: 'postgres',
      query: async (text, params = []) => [...((await sql.unsafe(text, params as any[])) as unknown as Row[])],
      exec: async (text) => {
        await sql.unsafe(text);
      },
    };
  }
  // Embedded Postgres (WASM) for zero-config local use.
  const { PGlite } = await import('@electric-sql/pglite');
  const dir = process.env.PGLITE_DIR || path.join(process.cwd(), '.data', 'pglite');
  fs.mkdirSync(path.dirname(dir), { recursive: true });
  const pg = new PGlite(dir);
  await pg.waitReady;
  return {
    kind: 'pglite',
    query: async (text, params = []) => (await pg.query(text, params)).rows as Row[],
    exec: async (text) => {
      await pg.exec(text);
    },
  };
}

async function init(): Promise<Driver> {
  const d = await open();
  if (d.kind === 'pglite') {
    await d.exec(buildDDL());
  } else {
    // Hosted Postgres (Supabase): the SQL in supabase/migrations is the source of truth.
    // If it has not been applied yet, create the tables now so a first deploy still works.
    const t = await d.query("SELECT to_regclass('public.profile') AS t");
    if (!t[0]?.t) {
      await d.exec(buildDDL());
      const hasAuth = await d.query("SELECT to_regnamespace('auth') AS n");
      if (hasAuth[0]?.n) await d.exec(buildRLS());
    }
  }
  if (process.env.AUTO_SEED !== 'false') {
    const { seedIfEmpty } = await import('./seed');
    await seedIfEmpty(d);
  }
  return d;
}

export function db(): Promise<Driver> {
  if (!g.__pkDb) {
    g.__pkDb = init().catch((e) => {
      g.__pkDb = undefined; // allow retry on next request
      throw e;
    });
  }
  return g.__pkDb;
}

/** Convenience: run a query and return rows */
export async function q<T = Row>(text: string, params: any[] = []): Promise<T[]> {
  const d = await db();
  return (await d.query(text, params)) as T[];
}

export async function one<T = Row>(text: string, params: any[] = []): Promise<T | null> {
  return (await q<T>(text, params))[0] ?? null;
}
