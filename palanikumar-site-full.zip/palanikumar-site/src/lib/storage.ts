import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads'));

export type UploadKind = 'image' | 'pdf';

const EXT_BY_KIND: Record<UploadKind, string[]> = { image: ['jpg', 'jpeg', 'png', 'webp', 'gif'], pdf: ['pdf'] };
// Vercel serverless functions reject request bodies above ~4.5 MB, so cap uploads lower there.
const ON_VERCEL = !!process.env.VERCEL;
const MAX_BYTES: Record<UploadKind, number> = ON_VERCEL ? { image: 4 * 1024 * 1024, pdf: 4 * 1024 * 1024 } : { image: 8 * 1024 * 1024, pdf: 25 * 1024 * 1024 };

export const MIME_BY_EXT: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', pdf: 'application/pdf',
};

/** Checks the real file signature, not just the extension the browser reports. */
function sniff(buf: Buffer): string | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  if (buf.subarray(0, 4).toString('ascii') === 'GIF8') return 'gif';
  if (buf.subarray(0, 5).toString('ascii') === '%PDF-') return 'pdf';
  return null;
}

export class UploadError extends Error {}

export async function saveUpload(file: File, kind: UploadKind, folder: string): Promise<string> {
  if (!file || typeof file.arrayBuffer !== 'function') throw new UploadError('No file received');
  if (file.size === 0) throw new UploadError('The file is empty');
  if (file.size > MAX_BYTES[kind]) throw new UploadError(`File is too large (max ${MAX_BYTES[kind] / 1024 / 1024} MB)`);
  const buf = Buffer.from(await file.arrayBuffer());
  const real = sniff(buf);
  if (!real || !EXT_BY_KIND[kind].includes(real)) {
    throw new UploadError(kind === 'pdf' ? 'Only PDF files are allowed' : 'Only JPG, PNG, WebP or GIF images are allowed');
  }
  const safeFolder = folder.replace(/[^a-z0-9-]/gi, '').slice(0, 30) || 'misc';
  const name = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}.${real}`;
  const rel = `${safeFolder}/${name}`;

  const sbUrl = process.env.SUPABASE_URL;
  const sbKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const bucket = process.env.SUPABASE_BUCKET || 'site-uploads';
  if (sbUrl && sbKey) {
    const res = await fetch(`${sbUrl.replace(/\/$/, '')}/storage/v1/object/${bucket}/${rel}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${sbKey}`, 'Content-Type': MIME_BY_EXT[real], 'x-upsert': 'false' },
      body: buf,
    });
    if (!res.ok) throw new UploadError(`Storage upload failed (${res.status})`);
    return `${sbUrl.replace(/\/$/, '')}/storage/v1/object/public/${bucket}/${rel}`;
  }

  if (ON_VERCEL) throw new UploadError('Uploads need Supabase Storage on Vercel. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (see DEPLOY.md).');
  const dest = path.join(UPLOAD_DIR, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, buf);
  return `/uploads/${rel}`;
}
