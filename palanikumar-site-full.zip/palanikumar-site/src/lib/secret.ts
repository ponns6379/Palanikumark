// Edge-safe (no Node imports): used by both middleware and server code.
export const COOKIE_NAME = 'pk_admin_session';

export function authSecret(): Uint8Array {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 32) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('AUTH_SECRET must be set to a random string of at least 32 characters.');
    }
    // Development-only fallback so `npm run dev` works out of the box.
    return new TextEncoder().encode('dev-only-insecure-secret-change-me-0123456789abcdef');
  }
  return new TextEncoder().encode(s);
}
