import { q, type Row } from './db';
import { tokenSimilarity } from './format';

export interface ImpactChain {
  patent: Row;
  work: Row[]; // matching consultancy / industry projects
}

/**
 * Builds "Innovation → Patent → Application → Industry impact" chains purely from records
 * already in the profile: a patent whose title matches a consultancy project title.
 * Nothing is invented — a chain exists only when both records exist.
 */
export async function getImpactChains(): Promise<ImpactChain[]> {
  const patents = await q("SELECT * FROM patents WHERE published = true ORDER BY status_date_iso DESC NULLS LAST");
  const work = await q('SELECT * FROM consultancy WHERE published = true');
  const chains: ImpactChain[] = [];
  for (const p of patents) {
    const hits = work.filter((w) => tokenSimilarity(p.title, w.title) >= 0.8);
    if (hits.length) chains.push({ patent: p, work: hits });
  }
  return chains;
}
