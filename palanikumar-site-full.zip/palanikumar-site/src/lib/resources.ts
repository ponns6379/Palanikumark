/**
 * Single source of truth for every content table.
 * - generates the SQL schema (see schema.ts)
 * - drives validation in the admin API
 * - drives the admin list/forms UI
 */
export type FieldType = 'text' | 'textarea' | 'number' | 'bool' | 'select' | 'image' | 'url';

export interface Field {
  name: string;
  label: string;
  type: FieldType;
  required?: boolean;
  options?: string[];
  list?: boolean; // show as a column in the admin list
  search?: boolean; // included in admin / public text search
  help?: string;
  max?: number;
}

export interface Resource {
  key: string; // table name
  slug: string; // admin URL segment
  label: string;
  singular: string;
  fields: Field[];
  order: string; // default SQL ORDER BY
  published?: boolean; // table has a `published` column
  sortable?: boolean; // table has a `sort_order` column
  titleField: string;
}

const f = (name: string, label: string, type: FieldType = 'text', o: Partial<Field> = {}): Field => ({ name, label, type, ...o });

const defs: Omit<Resource, 'key'>[] & { key: string }[] = [];
const add = (key: string, slug: string, label: string, singular: string, titleField: string, order: string, fields: Field[], o: { published?: boolean; sortable?: boolean } = {}) => {
  (defs as any[]).push({ key, slug, label, singular, titleField, order, fields, ...o });
};

add('stats', 'statistics', 'Research Statistics', 'Statistic', 'label', 'sort_order, id', [
  f('key', 'Key', 'text', { required: true, help: 'Unique identifier, e.g. scopus_articles' }),
  f('label', 'Label', 'text', { required: true, list: true, search: true }),
  f('value', 'Value', 'text', { required: true, list: true, help: 'Type the number exactly as it should appear (e.g. 10,310). For automatic counts use live:<table> (live:scholars, live:awards, live:projects, live:publications, live:patents, live:editorial_roles).' }),
  f('note', 'Source note', 'textarea', { help: 'Shown as small print under the number.' }),
  f('kind', 'Type', 'select', { options: ['stated', 'live'], list: true, help: '"stated" = number taken from the profile; "live" = counted from the database.' }),
  f('grp', 'Group', 'select', { options: ['publications', 'innovation', 'funding', 'supervision', 'recognition', 'editorial'], list: true }),
], { published: true, sortable: true });

add('qualifications', 'qualifications', 'Qualifications', 'Qualification', 'degree', 'sort_order, id', [
  f('degree', 'Degree / qualification', 'text', { required: true, list: true, search: true }),
  f('institution', 'Institution', 'text', { list: true, search: true }),
  f('year', 'Year', 'text', { list: true }),
  f('note', 'Note', 'textarea'),
  f('highlight', 'Highlight (e.g. rank)', 'bool', { list: true }),
], { sortable: true });

add('experience', 'experience', 'Experience', 'Experience entry', 'designation', 'sort_order, id', [
  f('designation', 'Designation', 'text', { required: true, list: true, search: true }),
  f('organization', 'Organization', 'text', { list: true, search: true }),
  f('start_year', 'From', 'text', { list: true }),
  f('end_year', 'To', 'text', { list: true }),
  f('duties', 'Nature of duties', 'textarea'),
  f('reason_for_leaving', 'Reason for leaving', 'text'),
  f('kind', 'Kind', 'select', { options: ['Teaching & Research', 'Other experience'], list: true }),
], { sortable: true });

add('research_interests', 'research-interests', 'Research Interests', 'Research interest', 'title', 'sort_order, id', [
  f('title', 'Title', 'text', { required: true, list: true, search: true }),
  f('description', 'Description', 'textarea', { search: true }),
  f('icon', 'Icon', 'select', { options: ['layers', 'leaf', 'drill', 'gauge', 'sliders', 'atom', 'flame', 'cog', 'flask', 'chip'], list: true }),
], { sortable: true });

add('publications', 'publications', 'Publications', 'Publication', 'title', 'year desc nulls last, title', [
  f('title', 'Title', 'textarea', { required: true, list: true, search: true, max: 1000 }),
  f('authors', 'Authors', 'textarea', { search: true }),
  f('journal', 'Journal / book / conference', 'text', { list: true, search: true }),
  f('year', 'Year', 'number', { list: true }),
  f('volume', 'Volume', 'text'),
  f('issue', 'Issue', 'text'),
  f('pages', 'Pages', 'text'),
  f('doi', 'DOI', 'text', { search: true, help: 'e.g. 10.1016/j.jmrt.2020.12.004' }),
  f('url', 'Link (URL)', 'url'),
  f('scopus', 'Scopus indexed', 'bool', { list: true }),
  f('wos', 'Web of Science indexed', 'bool', { list: true }),
  f('google_scholar', 'Google Scholar listed', 'bool', { list: true }),
  f('keywords', 'Keywords', 'text', { search: true }),
  f('citations', 'Citations', 'number'),
  f('raw_citation', 'Original citation text (from profile)', 'textarea'),
  f('featured', 'Featured on homepage', 'bool', { list: true }),
], { published: true, sortable: true });

add('patents', 'patents', 'Patents', 'Patent', 'title', 'status, status_date_iso desc nulls last, id', [
  f('application_no', 'Application / design number', 'text', { required: true, list: true, search: true }),
  f('title', 'Patent title', 'textarea', { required: true, list: true, search: true }),
  f('applicants', 'Applicants / inventors (separate with ;)', 'textarea', { search: true }),
  f('application_date', 'Application date (dd/mm/yyyy)', 'text', { list: true }),
  f('application_date_iso', 'Application date (yyyy-mm-dd, for sorting)', 'text'),
  f('status', 'Status', 'select', { options: ['Granted', 'Published', 'Filed'], required: true, list: true }),
  f('status_date', 'Grant / publication date (dd/mm/yyyy)', 'text', { list: true }),
  f('status_date_iso', 'Grant / publication date (yyyy-mm-dd)', 'text'),
  f('kind', 'Type', 'select', { options: ['Patent', 'Design'], list: true }),
  f('collaborators', 'Relevant collaborators', 'text'),
  f('link', 'Patent document / link', 'url'),
  f('featured', 'Featured on homepage', 'bool', { list: true }),
], { published: true, sortable: true });

add('projects', 'projects', 'Funded Projects', 'Project', 'title', 'source_no desc nulls last, id', [
  f('source_no', 'Serial no. in profile', 'number'),
  f('title', 'Project title', 'textarea', { required: true, list: true, search: true }),
  f('agency', 'Funding agency', 'text', { list: true, search: true }),
  f('amount', 'Amount (as written)', 'text', { list: true, help: 'Exactly as in the profile, e.g. "47.00 Lakhs"' }),
  f('amount_lakhs', 'Amount in lakhs (number, for totals)', 'number'),
  f('duration', 'Duration', 'text'),
  f('start_date', 'Start date', 'text'),
  f('end_date', 'End date', 'text'),
  f('grant_no', 'Grant / reference number', 'text', { search: true }),
  f('role', 'Role', 'text'),
  f('status', 'Status', 'text', { list: true }),
], { published: true, sortable: true });

add('scholars', 'scholars', 'Ph.D. Scholars', 'Scholar', 'name', 'completion_year desc nulls last, id', [
  f('name', 'Scholar name', 'text', { required: true, list: true, search: true }),
  f('title', 'Research title', 'textarea', { search: true, list: true }),
  f('university', 'University', 'text', { search: true }),
  f('completion', 'Date of completion (as written)', 'text', { list: true }),
  f('completion_year', 'Completion year', 'number', { list: true }),
  f('role', 'Role', 'select', { options: ['Supervisor', 'Joint Supervisor', 'Co-supervisor'], list: true }),
  f('area', 'Research area (filter tag)', 'select', { options: ['Metal Matrix Composites', 'Polymer & Natural Fibre Composites', 'Machining & Drilling', 'Welding & Joining', 'Other'], list: true }),
], { published: true, sortable: true });

add('awards', 'awards', 'Awards', 'Award', 'name', 'year desc nulls last, sort_order, id', [
  f('name', 'Award name', 'textarea', { required: true, list: true, search: true }),
  f('organization', 'Awarding organization', 'text', { list: true, search: true }),
  f('year', 'Year', 'number', { list: true }),
  f('category', 'Category', 'select', { options: ['Award', 'National Award', 'Global Recognition', 'Peer Review Recognition', 'Recognition', 'Academic Distinction', 'Leadership & Fellowship'], list: true }),
  f('description', 'Description', 'textarea'),
  f('image', 'Image / certificate', 'image'),
  f('featured', 'Featured on homepage', 'bool', { list: true }),
], { published: true, sortable: true });

add('memberships', 'memberships', 'Memberships', 'Membership', 'organization', 'sort_order, id', [
  f('organization', 'Organization', 'text', { required: true, list: true, search: true }),
  f('membership_type', 'Membership type', 'text', { list: true }),
  f('membership_no', 'Membership number', 'text', { list: true }),
  f('since', 'Since', 'text', { list: true }),
], { sortable: true });

add('editorial_roles', 'editorial', 'Editorial Roles', 'Editorial role', 'journal', 'sort_order, id', [
  f('position', 'Position', 'text', { required: true, list: true, search: true }),
  f('journal', 'Journal', 'text', { required: true, list: true, search: true }),
  f('from_year', 'From', 'text', { list: true }),
  f('to_year', 'To', 'text', { list: true }),
  f('category', 'Category', 'select', { options: ['Editorial Advisory Board', 'Associate Editor', 'Editorial Board', 'Peer Review'], list: true }),
], { sortable: true });

add('books', 'books', 'Books', 'Book / chapter', 'title', 'kind, year desc nulls last, sort_order, id', [
  f('kind', 'Type', 'select', { options: ['authored', 'chapter', 'edited', 'proceedings'], required: true, list: true, help: 'authored = books authored; chapter = book chapters; edited = books edited; proceedings = conference proceedings edited' }),
  f('title', 'Title', 'textarea', { required: true, list: true, search: true }),
  f('citation', 'Full citation', 'textarea', { search: true }),
  f('publisher', 'Publisher', 'text'),
  f('year', 'Year', 'number', { list: true }),
  f('doi', 'DOI', 'text'),
  f('cover', 'Cover image', 'image'),
  f('note', 'Note', 'textarea'),
], { sortable: true });

add('consultancy', 'consultancy', 'Consultancy', 'Consultancy project', 'title', 'sort_order, id', [
  f('title', 'Project title', 'textarea', { required: true, list: true, search: true }),
  f('client', 'Client', 'text', { list: true, search: true }),
  f('period', 'Period', 'text', { list: true }),
  f('amount', 'Consultancy amount', 'text', { list: true }),
  f('description', 'Description', 'textarea'),
], { published: true, sortable: true });

add('gallery', 'gallery', 'Gallery', 'Image', 'title', 'sort_order, id', [
  f('title', 'Title', 'text', { required: true, list: true, search: true }),
  f('category', 'Category', 'select', { options: ['Profile', 'Academic Events', 'Conferences', 'Awards', 'Research', 'Students', 'Institutional Events', 'International Visits', 'Publications / Books', 'Patents / Innovation'], required: true, list: true }),
  f('image', 'Image', 'image', { required: true }),
  f('caption', 'Caption', 'textarea'),
  f('event_name', 'Event name', 'text'),
  f('event_date', 'Event date', 'text'),
  f('link', 'External link', 'url'),
], { published: true, sortable: true });

add('news', 'news', 'News & Updates', 'Update', 'title', 'date desc, id desc', [
  f('title', 'Title', 'text', { required: true, list: true, search: true }),
  f('date', 'Date (yyyy-mm-dd)', 'text', { required: true, list: true }),
  f('category', 'Category', 'select', { options: ['News', 'Awards', 'Publications', 'Patents', 'Conferences', 'Research Funding', 'Editorial', 'Talks', 'Academic Activities', 'Institutional Activities'], list: true }),
  f('summary', 'Short description', 'textarea', { search: true }),
  f('image', 'Image', 'image'),
  f('link', 'External link', 'url'),
], { published: true });

add('social_links', 'social', 'Social Links', 'Social link', 'platform', 'sort_order, id', [
  f('platform', 'Platform', 'select', { options: ['LinkedIn', 'Facebook', 'Google Scholar', 'ResearchGate', 'ORCID', 'Scopus', 'Web of Science', 'X / Twitter', 'YouTube', 'Website'], required: true, list: true }),
  f('url', 'URL', 'url', { required: true, list: true }),
], { sortable: true });

export const RESOURCE_LIST = defs as unknown as Resource[];
export const RESOURCES: Record<string, Resource> = Object.fromEntries(RESOURCE_LIST.map((r) => [r.key, r]));
export const BY_SLUG: Record<string, Resource> = Object.fromEntries(RESOURCE_LIST.map((r) => [r.slug, r]));

/** Singleton "profile" table (one row, id = 1) — edited in Profile & Biography screens */
export const PROFILE_FIELDS: Field[] = [
  f('full_name', 'Full name', 'text', { required: true }),
  f('display_name', 'Display name (short)', 'text'),
  f('honorifics', 'Post-nominals', 'text', { help: 'e.g. M.E., Ph.D., FIE' }),
  f('designation', 'Designation', 'text', { required: true }),
  f('institution', 'Institution', 'text', { required: true }),
  f('location', 'Location', 'text'),
  f('tagline', 'Tagline', 'text'),
  f('qualification', 'Qualification (short)', 'text'),
  f('specialization', 'Specialization', 'text'),
  f('research_interest', 'Research interest (one line)', 'textarea'),
  f('email', 'Email', 'text'),
  f('alt_email', 'Alternate email', 'text'),
  f('phone', 'Phone', 'text'),
  f('biography', 'Biography (blank line between paragraphs)', 'textarea', { max: 20000 }),
  f('highlights', 'Highlights (one per line)', 'textarea', { max: 10000 }),
  f('photo', 'Profile photograph', 'image'),
];
export const PROFILE_BIO_FIELDS = ['biography', 'highlights'];

export const SETTING_KEYS: { key: string; label: string; type: FieldType; help?: string }[] = [
  { key: 'site_title', label: 'Site title (browser tab / search results)', type: 'text' },
  { key: 'site_description', label: 'Meta description', type: 'textarea' },
  { key: 'site_url', label: 'Public site URL', type: 'url', help: 'Used for canonical links and sitemap, e.g. https://www.drpalanikumar.com' },
  { key: 'cv_url', label: 'Full profile / CV (PDF)', type: 'url' },
  { key: 'footer_note', label: 'Footer note', type: 'text' },
];

/** Tables whose count can be used by `live:<table>` statistics */
export const LIVE_TABLES = ['scholars', 'awards', 'projects', 'publications', 'patents', 'editorial_roles', 'books', 'consultancy', 'memberships', 'news', 'gallery'];

export const SQL_TYPE: Record<FieldType, string> = {
  text: 'text', textarea: 'text', select: 'text', image: 'text', url: 'text', number: 'double precision', bool: 'boolean',
};
