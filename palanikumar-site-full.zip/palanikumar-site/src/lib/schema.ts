import { PROFILE_FIELDS, RESOURCE_LIST, SQL_TYPE } from './resources';

/** Builds the (idempotent) PostgreSQL schema from the resource registry. */
export function buildDDL(): string {
  const parts: string[] = [];

  // singleton profile
  parts.push(
    `CREATE TABLE IF NOT EXISTS profile (
  id integer PRIMARY KEY DEFAULT 1,
${PROFILE_FIELDS.map((fl) => `  ${fl.name} text NOT NULL DEFAULT ''`).join(',\n')},
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT profile_singleton CHECK (id = 1)
);`,
  );

  parts.push(`CREATE TABLE IF NOT EXISTS site_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);`);

  for (const r of RESOURCE_LIST) {
    const cols = r.fields.map((fl) => {
      const t = SQL_TYPE[fl.type];
      if (fl.type === 'bool') return `  ${fl.name} boolean NOT NULL DEFAULT false`;
      if (fl.type === 'number') return `  ${fl.name} double precision`;
      return `  ${fl.name} text NOT NULL DEFAULT ''`.replace('text', t);
    });
    if (r.published) cols.push('  published boolean NOT NULL DEFAULT true');
    if (r.sortable) cols.push('  sort_order integer NOT NULL DEFAULT 0');
    cols.push('  created_at timestamptz NOT NULL DEFAULT now()', '  updated_at timestamptz NOT NULL DEFAULT now()');
    parts.push(`CREATE TABLE IF NOT EXISTS ${r.key} (\n  id serial PRIMARY KEY,\n${cols.join(',\n')}\n);`);
  }

  parts.push(`CREATE UNIQUE INDEX IF NOT EXISTS stats_key_uq ON stats (key);`);
  parts.push(`CREATE INDEX IF NOT EXISTS publications_year_idx ON publications (year);`);
  parts.push(`CREATE INDEX IF NOT EXISTS publications_doi_idx ON publications (doi);`);
  parts.push(`CREATE INDEX IF NOT EXISTS patents_status_idx ON patents (status);`);
  parts.push(`CREATE INDEX IF NOT EXISTS news_date_idx ON news (date);`);

  parts.push(`CREATE TABLE IF NOT EXISTS admin_users (
  id serial PRIMARY KEY,
  email text NOT NULL UNIQUE,
  name text NOT NULL DEFAULT '',
  password_hash text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);`);

  parts.push(`CREATE TABLE IF NOT EXISTS audit_log (
  id serial PRIMARY KEY,
  user_email text NOT NULL DEFAULT '',
  action text NOT NULL,
  resource text NOT NULL DEFAULT '',
  record_id text NOT NULL DEFAULT '',
  detail text NOT NULL DEFAULT '',
  ip text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);`);

  return parts.join('\n\n');
}

/**
 * Row Level Security for Supabase. Public visitors (anon key) may read published content only;
 * only users listed in admin_users may write. The Next.js server connects with the database owner role
 * (DATABASE_URL), which bypasses RLS — it is never exposed to the browser.
 */
export function buildRLS(): string {
  const parts: string[] = [];
  parts.push(`CREATE OR REPLACE FUNCTION public.is_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.admin_users WHERE email = lower(coalesce(auth.jwt() ->> 'email', '')));
$$;`);
  const tables: { key: string; published: boolean }[] = [
    { key: 'profile', published: false },
    { key: 'site_settings', published: false },
    ...RESOURCE_LIST.map((r) => ({ key: r.key, published: !!r.published })),
  ];
  for (const t of tables) {
    parts.push(`ALTER TABLE public.${t.key} ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public read" ON public.${t.key};
CREATE POLICY "public read" ON public.${t.key} FOR SELECT TO anon, authenticated USING (${t.published ? 'published = true OR public.is_admin()' : 'true'});
DROP POLICY IF EXISTS "admin write" ON public.${t.key};
CREATE POLICY "admin write" ON public.${t.key} FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());`);
  }
  // admin allow-list and audit log: never readable by the public; no policy on admin_users = deny all (except via the definer function)
  parts.push(`ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "admin read" ON public.audit_log;
CREATE POLICY "admin read" ON public.audit_log FOR SELECT TO authenticated USING (public.is_admin());`);
  return parts.join('\n\n');
}

/** Storage bucket for uploaded photographs and the CV. Public read, admin-only write. */
export function buildStorageSQL(bucket = 'site-uploads'): string {
  return `INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('${bucket}', '${bucket}', true, 4194304, ARRAY['image/jpeg','image/png','image/webp','image/gif','application/pdf'])
ON CONFLICT (id) DO UPDATE SET public = true, file_size_limit = 4194304,
  allowed_mime_types = ARRAY['image/jpeg','image/png','image/webp','image/gif','application/pdf'];

DROP POLICY IF EXISTS "site uploads public read" ON storage.objects;
CREATE POLICY "site uploads public read" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = '${bucket}');
DROP POLICY IF EXISTS "site uploads admin insert" ON storage.objects;
CREATE POLICY "site uploads admin insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = '${bucket}' AND public.is_admin());
DROP POLICY IF EXISTS "site uploads admin update" ON storage.objects;
CREATE POLICY "site uploads admin update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = '${bucket}' AND public.is_admin());
DROP POLICY IF EXISTS "site uploads admin delete" ON storage.objects;
CREATE POLICY "site uploads admin delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = '${bucket}' AND public.is_admin());`;
}
