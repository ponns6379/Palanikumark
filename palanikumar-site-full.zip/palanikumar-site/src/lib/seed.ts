import fs from 'node:fs';
import path from 'node:path';
import type { Driver, Row } from './db';
import { PROFILE_FIELDS, RESOURCE_LIST } from './resources';

const SEED_DIR = path.join(process.cwd(), 'data', 'seed');
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => '_' + m.toLowerCase());
const load = (name: string): any => JSON.parse(fs.readFileSync(path.join(SEED_DIR, name + '.json'), 'utf8'));

async function insert(d: Driver, table: string, cols: string[], rows: any[][]) {
  for (const vals of rows) {
    const ph = vals.map((_, i) => `$${i + 1}`).join(',');
    await d.query(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${ph})`, vals);
  }
}

export async function seedIfEmpty(d: Driver) {
  const r = await d.query('SELECT count(*)::int AS c FROM profile');
  if (r[0]?.c > 0) return false;
  await seedAll(d);
  return true;
}

/** Loads data/seed/*.json (extracted from the Bio-Data) into the database. */
export async function seedAll(d: Driver, opts: { wipe?: boolean } = {}) {
  if (opts.wipe) {
    for (const r of RESOURCE_LIST) await d.exec(`TRUNCATE TABLE ${r.key} RESTART IDENTITY`);
    await d.exec('TRUNCATE TABLE profile; TRUNCATE TABLE site_settings;');
  }
  // profile (singleton)
  const p = load('profile');
  const prow: Row = { ...p };
  prow.full_name = p.fullName; prow.display_name = p.displayName; prow.research_interest = p.researchInterest; prow.alt_email = p.altEmail;
  prow.biography = (p.biography as string[]).join('\n\n');
  prow.highlights = (p.highlights as string[]).join('\n');
  const pcols = PROFILE_FIELDS.map((f) => f.name);
  await d.query(
    `INSERT INTO profile (id, ${pcols.join(',')}) VALUES (1, ${pcols.map((_, i) => `$${i + 1}`).join(',')})`,
    pcols.map((c) => String(prow[c] ?? '')),
  );

  // settings
  const settings = load('site_settings') as { key: string; value: string }[];
  for (const s of settings) {
    const value = s.key === 'cv_url' ? '/files/Bio-Data-K-Palanikumar.pdf' : s.key === 'site_url' ? process.env.NEXT_PUBLIC_SITE_URL || s.value : s.value;
    await d.query('INSERT INTO site_settings (key, value) VALUES ($1,$2) ON CONFLICT (key) DO NOTHING', [s.key, value]);
  }

  // content tables
  for (const res of RESOURCE_LIST) {
    let items: any[];
    try {
      items = load(res.key);
    } catch {
      continue;
    }
    const cols = [...res.fields.map((f) => f.name)];
    if (res.published) cols.push('published');
    if (res.sortable) cols.push('sort_order');
    const rows = items.map((it, idx) => {
      const o: Record<string, any> = {};
      for (const [k, v] of Object.entries(it)) o[k === 'group' ? 'grp' : snake(k)] = v;
      if (res.sortable && o.sort_order === undefined) o.sort_order = idx;
      return cols.map((c) => {
        const f = res.fields.find((x) => x.name === c);
        let v = o[c];
        if (f?.type === 'bool') return v === undefined ? false : !!v;
        if (c === 'published') return v === undefined ? true : !!v;
        if (f?.type === 'number') return v === undefined || v === null || v === '' ? null : Number(v);
        if (c === 'sort_order') return Number(v ?? idx);
        return v === undefined || v === null ? '' : String(v);
      });
    });
    await insert(d, res.key, cols, rows);
  }
}
