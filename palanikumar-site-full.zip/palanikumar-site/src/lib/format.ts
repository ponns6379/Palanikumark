export const paragraphs = (s: string) => (s || '').split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
export const lines = (s: string) => (s || '').split(/\n/).map((p) => p.trim()).filter(Boolean);

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export function fmtDate(iso?: string | null) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  if (!m) return iso || '';
  return `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[1]}`;
}

export const normalizeTitle = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

export function tokenSimilarity(a: string, b: string) {
  const A = new Set(normalizeTitle(a).split(' ').filter((w) => w.length > 2));
  const B = new Set(normalizeTitle(b).split(' ').filter((w) => w.length > 2));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  A.forEach((w) => B.has(w) && inter++);
  return inter / (A.size + B.size - inter);
}

export function initials(name: string) {
  return name.replace(/\b(Dr|Mr|Ms|Prof)\.?\s/gi, '').split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase();
}

export function qs(base: string, params: Record<string, string | number | undefined | null>) {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && String(v) !== '') u.set(k, String(v));
  const s = u.toString();
  return s ? `${base}?${s}` : base;
}

export const fmtNumber = (n: number) => n.toLocaleString('en-IN');
export const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? '';
