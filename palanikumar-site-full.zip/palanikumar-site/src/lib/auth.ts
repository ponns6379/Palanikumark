import { cookies, headers } from 'next/headers';
import { SignJWT, jwtVerify } from 'jose';
import bcrypt from 'bcryptjs';
import { COOKIE_NAME, authSecret } from './secret';
import { one, q } from './db';

export interface Session {
  id: number;
  email: string;
  name: string;
}

const MAX_AGE = 60 * 60 * 8; // 8 hours

export async function hashPassword(pw: string) {
  return bcrypt.hash(pw, 12);
}

export async function createSession(u: Session) {
  const token = await new SignJWT({ email: u.email, name: u.name })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(String(u.id))
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(authSecret());
  (await cookies()).set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE,
  });
}

export async function destroySession() {
  (await cookies()).set(COOKIE_NAME, '', { httpOnly: true, path: '/', maxAge: 0 });
}

/** Verifies the cookie AND that the admin account still exists. */
export async function getSession(): Promise<Session | null> {
  const t = (await cookies()).get(COOKIE_NAME)?.value;
  if (!t) return null;
  try {
    const { payload } = await jwtVerify(t, authSecret(), { algorithms: ['HS256'] });
    const id = Number(payload.sub);
    const u = await one<{ id: number; email: string; name: string }>('SELECT id, email, name FROM admin_users WHERE id = $1', [id]);
    return u ? { id: u.id, email: u.email, name: u.name } : null;
  } catch {
    return null;
  }
}

export async function clientIp(): Promise<string> {
  const h = await headers();
  return (h.get('x-forwarded-for')?.split(',')[0] || h.get('x-real-ip') || 'unknown').trim();
}

export async function audit(user: string, action: string, resource = '', recordId: string | number = '', detail = '') {
  try {
    const ip = await clientIp();
    await q('INSERT INTO audit_log (user_email, action, resource, record_id, detail, ip) VALUES ($1,$2,$3,$4,$5,$6)', [user, action, resource, String(recordId), detail.slice(0, 500), ip]);
  } catch {
    /* logging must never break a request */
  }
}

// --- very small in-memory login rate limiter (per server instance) ---
const attempts = new Map<string, { n: number; t: number }>();
export function rateLimited(key: string, max = 6, windowMs = 15 * 60 * 1000): boolean {
  const now = Date.now();
  const a = attempts.get(key);
  if (!a || now - a.t > windowMs) {
    attempts.set(key, { n: 1, t: now });
    return false;
  }
  a.n += 1;
  return a.n > max;
}
export function clearRate(key: string) {
  attempts.delete(key);
}
