import { getSettings } from './queries';

export async function siteUrl(): Promise<string> {
  const env = process.env.NEXT_PUBLIC_SITE_URL;
  const s = env || (await getSettings().catch(() => ({} as Record<string, string>))).site_url || 'http://localhost:3000';
  return s.replace(/\/+$/, '');
}
