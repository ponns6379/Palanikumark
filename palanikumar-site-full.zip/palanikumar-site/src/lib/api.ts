import { NextResponse } from 'next/server';
import { getSession, type Session } from './auth';

export const json = (data: unknown, status = 200) => NextResponse.json(data, { status });

/** Returns the admin session or a ready-made 401 response. */
export async function requireAdmin(): Promise<{ session: Session } | { error: NextResponse }> {
  const session = await getSession();
  if (!session) return { error: json({ error: 'Unauthorized' }, 401) };
  return { session };
}
