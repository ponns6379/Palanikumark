import Link from 'next/link';
import { qs } from '@/lib/format';

export function Pagination({ base, params, page, pages }: { base: string; params: Record<string, string | number | undefined>; page: number; pages: number }) {
  if (pages <= 1) return null;
  const nums: (number | '…')[] = [];
  for (let i = 1; i <= pages; i++) {
    if (i === 1 || i === pages || Math.abs(i - page) <= 1) nums.push(i);
    else if (nums[nums.length - 1] !== '…') nums.push('…');
  }
  const href = (p: number) => qs(base, { ...params, page: p > 1 ? p : undefined });
  const cls = 'inline-flex h-9 min-w-9 items-center justify-center rounded border px-3 text-sm no-underline';
  return (
    <nav aria-label="Pagination" className="mt-8 flex flex-wrap items-center justify-center gap-1.5">
      {page > 1 ? <Link href={href(page - 1)} className={`${cls} border-line bg-white text-navy hover:border-navy`}>Previous</Link> : <span className={`${cls} border-transparent text-ink-mute`}>Previous</span>}
      {nums.map((n, i) =>
        n === '…' ? (
          <span key={`e${i}`} className="px-1 text-ink-mute">…</span>
        ) : (
          <Link key={n} href={href(n)} aria-current={n === page ? 'page' : undefined} className={`${cls} ${n === page ? 'border-navy bg-navy text-white' : 'border-line bg-white text-navy hover:border-navy'}`}>
            {n}
          </Link>
        ),
      )}
      {page < pages ? <Link href={href(page + 1)} className={`${cls} border-line bg-white text-navy hover:border-navy`}>Next</Link> : <span className={`${cls} border-transparent text-ink-mute`}>Next</span>}
    </nav>
  );
}
