'use client';
import { useCallback, useEffect, useRef, useState } from 'react';

export type GalleryItem = { id: number; title: string; category: string; image: string; caption: string; event_name: string; event_date: string; link: string };

export function GalleryGrid({ items }: { items: GalleryItem[] }) {
  const [open, setOpen] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const opener = useRef<HTMLElement | null>(null);

  const close = useCallback(() => {
    setOpen(null);
    opener.current?.focus();
  }, []);
  const step = useCallback((d: number) => setOpen((i) => (i === null ? i : (i + d + items.length) % items.length)), [items.length]);

  useEffect(() => {
    if (open === null) return;
    closeRef.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowRight') step(1);
      if (e.key === 'ArrowLeft') step(-1);
    };
    document.addEventListener('keydown', key);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', key);
      document.body.style.overflow = prev;
    };
  }, [open, close, step]);

  const cur = open !== null ? items[open] : null;
  return (
    <>
      <ul className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {items.map((g, i) => (
          <li key={g.id}>
            <figure className="card overflow-hidden">
              <button
                type="button"
                className="block w-full bg-navy-50"
                aria-label={`Enlarge: ${g.title}`}
                onClick={(e) => {
                  opener.current = e.currentTarget;
                  setOpen(i);
                }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={g.image} alt={g.caption || g.title} loading="lazy" decoding="async" className="aspect-[4/3] w-full object-cover transition-transform duration-300 hover:scale-[1.03]" />
              </button>
              <figcaption className="p-3">
                <p className="text-sm font-medium leading-snug text-ink">{g.title}</p>
                <p className="mt-0.5 text-xs text-ink-mute">{[g.category, g.event_date].filter(Boolean).join(' · ')}</p>
              </figcaption>
            </figure>
          </li>
        ))}
      </ul>

      {cur && (
        <div className="fixed inset-0 z-50 flex flex-col bg-navy/95 p-4" role="dialog" aria-modal="true" aria-label={cur.title} onClick={close}>
          <div className="flex justify-end">
            <button ref={closeRef} type="button" onClick={close} className="rounded px-3 py-1.5 text-sm font-semibold text-white ring-1 ring-white/40 hover:bg-white/10">Close ✕</button>
          </div>
          <div className="relative flex min-h-0 flex-1 items-center justify-center" onClick={(e) => e.stopPropagation()}>
            {items.length > 1 && (
              <button type="button" aria-label="Previous image" onClick={() => step(-1)} className="absolute left-0 z-10 rounded-full bg-white/15 px-3 py-2 text-xl text-white hover:bg-white/25">‹</button>
            )}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={cur.image} alt={cur.caption || cur.title} className="max-h-full max-w-full rounded object-contain" />
            {items.length > 1 && (
              <button type="button" aria-label="Next image" onClick={() => step(1)} className="absolute right-0 z-10 rounded-full bg-white/15 px-3 py-2 text-xl text-white hover:bg-white/25">›</button>
            )}
          </div>
          <div className="mx-auto mt-3 max-w-2xl text-center text-white" onClick={(e) => e.stopPropagation()}>
            <p className="font-serif text-lg">{cur.title}</p>
            {(cur.event_name || cur.event_date) && <p className="text-sm text-white/70">{[cur.event_name, cur.event_date].filter(Boolean).join(' · ')}</p>}
            {cur.caption && cur.caption !== cur.title && <p className="mt-1 text-sm text-white/80">{cur.caption}</p>}
            {cur.link && <a href={cur.link} target="_blank" rel="noopener noreferrer" className="mt-1 inline-block text-sm text-gold underline">More about this</a>}
          </div>
        </div>
      )}
    </>
  );
}
