import Link from 'next/link';
import type { ReactNode } from 'react';
import { qs } from '@/lib/format';
import { Icon } from './Icon';

export function PageHeader({ eyebrow, title, intro, children }: { eyebrow?: string; title: string; intro?: ReactNode; children?: ReactNode }) {
  return (
    <section className="precision-grid border-b border-line bg-gradient-to-b from-white to-paper">
      <div className="container-page py-12 sm:py-16">
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h1 className="mt-2 max-w-3xl text-4xl font-semibold leading-tight sm:text-5xl">{title}</h1>
        {intro && <div className="lead mt-4 max-w-3xl">{intro}</div>}
        {children}
      </div>
    </section>
  );
}

export function SectionHead({ eyebrow, title, intro, href, cta }: { eyebrow?: string; title: string; intro?: ReactNode; href?: string; cta?: string }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h2 className="h-section">{title}</h2>
        {intro && <p className="mt-3 text-ink-soft">{intro}</p>}
      </div>
      {href && (
        <Link href={href} className="inline-flex items-center gap-1.5 text-sm font-semibold no-underline">
          {cta ?? 'View all'} <Icon name="arrow" className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}

export function Empty({ children = 'Nothing to show yet.' }: { children?: ReactNode }) {
  return <p className="rounded-md border border-dashed border-line bg-white px-6 py-10 text-center text-ink-mute">{children}</p>;
}

/** GET-based search box (works without JS). Keeps other params as hidden inputs. */
export function SearchBox({ action, q, placeholder, hidden = {} }: { action: string; q: string; placeholder: string; hidden?: Record<string, string | undefined> }) {
  return (
    <form action={action} method="get" role="search" className="relative w-full max-w-md">
      {Object.entries(hidden).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null))}
      <label htmlFor={`s-${action}`} className="sr-only">Search</label>
      <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
      <input id={`s-${action}`} name="q" defaultValue={q} placeholder={placeholder} className="field pl-9" />
    </form>
  );
}

export function FilterChips({ base, param, options, current, params }: { base: string; param: string; options: { value: string; label: string; count?: number }[]; current: string; params: Record<string, string | undefined> }) {
  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label="Filters">
      {options.map((o) => {
        const on = (current || '') === o.value;
        return (
          <Link
            key={o.value || 'all'}
            href={qs(base, { ...params, [param]: o.value || undefined, page: undefined })}
            aria-current={on ? 'true' : undefined}
            className={`rounded-full border px-3.5 py-1.5 text-sm no-underline transition-colors ${on ? 'border-navy bg-navy text-white' : 'border-line bg-white text-ink-soft hover:border-navy hover:text-navy'}`}
          >
            {o.label}
            {o.count !== undefined && <span className={`ml-1.5 text-xs ${on ? 'text-white/70' : 'text-ink-mute'}`}>{o.count}</span>}
          </Link>
        );
      })}
    </div>
  );
}

export function Stat({ value, label, note, tone = 'navy' }: { value: string; label: string; note?: string; tone?: 'navy' | 'teal' | 'gold' }) {
  const c = tone === 'teal' ? 'text-teal' : tone === 'gold' ? 'text-gold-600' : 'text-navy';
  return (
    <div className="card card-pad">
      <p className={`font-serif text-4xl font-semibold leading-none ${c}`}>{value}</p>
      <p className="mt-2 text-sm font-medium text-ink">{label}</p>
      {note && <p className="mt-1 text-xs leading-snug text-ink-mute">{note}</p>}
    </div>
  );
}

export const PAGE_SIZE = 15;
export const pageOf = (v: string, total: number, size = PAGE_SIZE) => {
  const pages = Math.max(1, Math.ceil(total / size));
  const page = Math.min(Math.max(parseInt(v || '1', 10) || 1, 1), pages);
  return { page, pages, offset: (page - 1) * size, size };
};
