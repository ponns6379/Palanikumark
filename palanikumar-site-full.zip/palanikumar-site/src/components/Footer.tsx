import Link from 'next/link';
import { Icon } from './Icon';
import type { Row } from '@/lib/db';

export function Footer({ profile, social, note, cv }: { profile: Row; social: Row[]; note: string; cv: string }) {
  return (
    <footer className="mt-10 bg-navy text-white/80">
      <div className="container-page grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <p className="font-serif text-xl text-white">{profile.full_name}</p>
          <p className="mt-1 text-sm text-white/70">
            {profile.designation}, {profile.institution}
          </p>
          <p className="text-sm text-white/70">{profile.location}</p>
          <div className="mt-5 flex gap-3">
            {social.map((s) => (
              <a key={s.id} href={s.url} target="_blank" rel="noopener noreferrer" aria-label={s.platform} className="flex h-9 w-9 items-center justify-center rounded-full border border-white/25 text-white/80 hover:border-gold hover:text-gold">
                <Icon name={s.platform === 'LinkedIn' ? 'linkedin' : s.platform === 'Facebook' ? 'facebook' : 'link'} className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gold">Explore</p>
          <ul className="mt-3 space-y-2 text-sm">
            {[['/about', 'About'], ['/research', 'Research'], ['/publications', 'Publications'], ['/patents', 'Patents'], ['/projects', 'Projects & Funding'], ['/awards', 'Awards']].map(([h, l]) => (
              <li key={h}><Link href={h} className="text-white/80 no-underline hover:text-white">{l}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gold">Contact</p>
          <ul className="mt-3 space-y-2 text-sm">
            {profile.email && <li><a href={`mailto:${profile.email}`} className="break-all text-white/80 hover:text-white">{profile.email}</a></li>}
            {profile.alt_email && <li><a href={`mailto:${profile.alt_email}`} className="break-all text-white/80 hover:text-white">{profile.alt_email}</a></li>}
            {cv && <li><a href={cv} className="inline-flex items-center gap-1.5 text-white/80 hover:text-white"><Icon name="download" className="h-4 w-4" />Download full profile (PDF)</a></li>}
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-page flex flex-col gap-1 py-5 text-xs text-white/55 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} {profile.full_name}. All rights reserved.</p>
          <p>{note}</p>
        </div>
      </div>
    </footer>
  );
}
