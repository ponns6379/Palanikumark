'use client';
import { useState } from 'react';
import type { Field } from '@/lib/resources';
import { call } from './client';
import { FieldInput, FileField, RecordForm } from './RecordForm';

export function ProfileForm({ fields, initial }: { fields: Field[]; initial: Record<string, any> }) {
  const [saved, setSaved] = useState('');
  return (
    <>
      {saved && <p role="status" className="mb-4 rounded bg-teal-100 px-3 py-2 text-sm text-teal-700">{saved}</p>}
      <RecordForm
        fields={fields}
        initial={initial}
        folder="profile"
        submitLabel="Save profile"
        onSubmit={async (v) => {
          setSaved('');
          const r = await call('PUT', '/api/admin/profile', v);
          if (!r.ok) return { error: r.data.error, fields: r.data.fields };
          setSaved('Profile saved. Public pages update immediately.');
        }}
      />
    </>
  );
}

export function SettingsForm({ keys, initial }: { keys: { key: string; label: string; type: Field['type']; help?: string }[]; initial: Record<string, string> }) {
  const [v, setV] = useState<Record<string, string>>(initial);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ t: string; ok: boolean } | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    setErrs({});
    const r = await call('PUT', '/api/admin/settings', v);
    setBusy(false);
    if (r.ok) setMsg({ t: 'Settings saved.', ok: true });
    else { setErrs(r.data.fields || {}); setMsg({ t: r.data.error || 'Could not save', ok: false }); }
  };
  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      {keys.map((k) =>
        k.key === 'cv_url' ? (
          <div key={k.key}>
            <p className="label">{k.label}</p>
            <FileField kind="pdf" folder="cv" value={v.cv_url ?? ''} onChange={(x) => setV((p) => ({ ...p, cv_url: x }))} />
            <p className="mt-1 text-xs text-ink-mute">Upload a new PDF to replace the downloadable CV. The “Download CV” buttons use this file.</p>
            {errs.cv_url && <p role="alert" className="mt-1 text-xs text-red-700">{errs.cv_url}</p>}
          </div>
        ) : (
          <FieldInput key={k.key} f={{ name: k.key, label: k.label, type: k.type, help: k.help }} value={v[k.key]} onChange={(x) => setV((p) => ({ ...p, [k.key]: x }))} error={errs[k.key]} folder="site" />
        ),
      )}
      {msg && <p role="alert" className={`rounded px-3 py-2 text-sm ${msg.ok ? 'bg-teal-100 text-teal-700' : 'bg-red-50 text-red-800'}`}>{msg.t}</p>}
      <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save settings'}</button>
    </form>
  );
}
