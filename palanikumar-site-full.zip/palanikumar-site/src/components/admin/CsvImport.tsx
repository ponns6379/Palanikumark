'use client';
import { useState } from 'react';
import type { Resource } from '@/lib/resources';
import { call } from './client';

type Result = { total: number; valid: number; invalid: number; unknownColumns: string[]; errors: { row: number; errors: Record<string, string> }[]; committed?: boolean; imported?: number; error?: string };

export function CsvImport({ res, onClose, onDone }: { res: Resource; onClose: () => void; onDone: (n: number) => void }) {
  const [csv, setCsv] = useState('');
  const [name, setName] = useState('');
  const [r, setR] = useState<Result | null>(null);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const run = async (text: string, commit: boolean) => {
    setBusy(true);
    setMsg('');
    const x = await call<Result>('POST', `/api/admin/import/${res.slug}`, { csv: text, commit });
    setBusy(false);
    if (x.data.total !== undefined) setR(x.data as Result);
    else setR(null);
    if (!x.ok) setMsg(x.data.error || 'Import failed');
    if (x.ok && commit) onDone((x.data as Result).imported ?? 0);
  };

  const pick = async (f?: File | null) => {
    if (!f) return;
    if (f.size > 3_000_000) return setMsg('File is larger than 3 MB.');
    const text = await f.text();
    setCsv(text);
    setName(f.name);
    setR(null);
    run(text, false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-navy/50 p-4 sm:p-8" role="dialog" aria-modal="true" aria-label="Import CSV">
      <div className="w-full max-w-2xl rounded-md bg-white p-6 shadow-card">
        <h2 className="text-xl font-semibold">Import {res.label} from CSV</h2>
        <p className="mt-1 text-sm text-ink-soft">
          Use the same columns as an export. <a href={`/api/admin/export/${res.slug}?template=1`}>Download a blank template</a>. Every row is checked first; nothing is imported unless all rows are valid.
        </p>
        <div className="mt-4">
          <label className="btn btn-ghost cursor-pointer px-3 py-2 text-sm">
            Choose CSV file
            <input type="file" accept=".csv,text/csv" className="sr-only" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
          </label>
          {name && <span className="ml-3 text-sm text-ink-mute">{name}</span>}
        </div>
        {busy && <p className="mt-4 text-sm text-ink-mute">Checking…</p>}
        {msg && <p role="alert" className="mt-4 rounded border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">{msg}</p>}
        {r && (
          <div className="mt-4 space-y-3 text-sm">
            <p>
              <strong>{r.total}</strong> rows · <span className="text-teal-700">{r.valid} valid</span> · <span className={r.invalid ? 'text-red-700' : ''}>{r.invalid} with errors</span>
            </p>
            {r.unknownColumns?.length > 0 && <p className="text-gold-600">Ignored unknown columns: {r.unknownColumns.join(', ')}</p>}
            {r.errors.length > 0 && (
              <ul className="max-h-56 overflow-y-auto rounded border border-line">
                {r.errors.map((e) => (
                  <li key={e.row} className="border-b border-line px-3 py-2 last:border-0">
                    <span className="font-semibold">Row {e.row}:</span> {Object.entries(e.errors).map(([k, v]) => `${k} — ${v}`).join('; ')}
                  </li>
                ))}
                {r.invalid > r.errors.length && <li className="px-3 py-2 text-ink-mute">…and {r.invalid - r.errors.length} more rows with errors.</li>}
              </ul>
            )}
          </div>
        )}
        <div className="mt-6 flex gap-3">
          <button className="btn btn-primary" disabled={busy || !r || r.invalid > 0 || r.valid === 0} onClick={() => run(csv, true)}>
            {r && r.valid > 0 && r.invalid === 0 ? `Import ${r.valid} rows` : 'Import'}
          </button>
          <button className="btn btn-ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
