'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import { Icon } from '../Icon';

type NavItem = { href: string; label: string };

export function AdminShell({ user, groups, children }: { user: { name: string; email: string }; groups: { title: string; items: NavItem[] }[]; children: React.ReactNode }) {
  const path = usePathname() || '';
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const logout = async () => {
    await fetch('/api/admin/logout', { method: 'POST', credentials: 'same-origin' });
    router.push('/admin/login');
    router.refresh();
  };
  const nav = (
    <nav aria-label="Admin" className="space-y-5 px-3 py-4">
      {groups.map((g) => (
        <div key={g.title}>
          <p className="px-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-gold">{g.title}</p>
          <ul className="mt-1.5 space-y-0.5">
            {g.items.map((i) => {
              const on = i.href === '/admin' ? path === '/admin' : path === i.href || path.startsWith(i.href + '/');
              return (
                <li key={i.href}>
                  <Link href={i.href} onClick={() => setOpen(false)} aria-current={on ? 'page' : undefined} className={`block rounded px-2.5 py-1.5 text-sm no-underline ${on ? 'bg-white/15 font-semibold text-white hover:text-white' : 'text-white/75 hover:bg-white/10 hover:text-white'}`}>
                    {i.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[250px_1fr]">
      <aside className={`${open ? 'block' : 'hidden'} fixed inset-0 z-40 overflow-y-auto bg-navy lg:static lg:block`}>
        <div className="flex items-center justify-between px-5 pt-5">
          <p className="font-serif text-lg text-white">Admin panel</p>
          <button className="text-white lg:hidden" aria-label="Close menu" onClick={() => setOpen(false)}><Icon name="close" /></button>
        </div>
        {nav}
      </aside>
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-white px-4 py-3 sm:px-6">
          <button className="rounded p-1.5 text-navy lg:hidden" aria-label="Open menu" onClick={() => setOpen(true)}><Icon name="menu" /></button>
          <Link href="/" target="_blank" className="hidden text-sm lg:inline-flex lg:items-center lg:gap-1">View public site <Icon name="external" className="h-3.5 w-3.5" /></Link>
          <div className="flex items-center gap-4 text-sm">
            <span className="hidden text-ink-soft sm:inline">{user.name || user.email}</span>
            <button onClick={logout} className="btn btn-ghost px-3 py-1.5">Sign out</button>
          </div>
        </header>
        <main className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
