'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { Resource } from '@/lib/resources';
import { call, upload } from './client';
import { CsvImport } from './CsvImport';
import { RecordForm } from './RecordForm';
import { initialValues } from './values';

type Row = Record<string, any>;
const PAGE = 20;

export function ResourceManager({ res }: { res: Resource }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [text, setText] = useState('');
  const [typed, setTyped] = useState('');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [pub, setPub] = useState('');
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Row | 'new' | null>(null);
  const [toast, setToast] = useState<{ t: string; ok: boolean } | null>(null);
  const [reorder, setReorder] = useState(false);
  const [dragId, setDragId] = useState<number | null>(null);
  const [uploading, setUploading] = useState(false);
  const [dropCat, setDropCat] = useState('');
  const [importing, setImporting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const selects = res.fields.filter((f) => f.type === 'select' && f.list);
  const cols = res.fields.filter((f) => f.list).slice(0, 5);
  const isGallery = res.key === 'gallery';
  const filtered = !!(text || pub || Object.values(filters).some(Boolean));
  const canReorder = !!res.sortable && !filtered;
  const pageSize = reorder ? 100 : PAGE;

  const flash = (t: string, ok = true) => {
    setToast({ t, ok });
    setTimeout(() => setToast(null), 4000);
  };

  const load = useCallback(async () => {
    setLoading(true);
    const p = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
    if (text) p.set('q', text);
    if (pub) p.set('published', pub);
    for (const [k, v] of Object.entries(filters)) if (v) p.set(`f_${k}`, v);
    const r = await call<{ rows: Row[]; total: number }>('GET', `/api/admin/resources/${res.slug}?${p}`);
    setLoading(false);
    if (r.ok) { setRows(r.data.rows); setTotal(r.data.total); } else flash(r.data.error || 'Could not load records', false);
  }, [res.slug, page, pageSize, text, pub, filters]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { const t = setTimeout(() => { setText(typed.trim()); setPage(1); }, 300); return () => clearTimeout(t); }, [typed]);

  const save = async (values: Row) => {
    const isNew = editing === 'new';
    const r = isNew
      ? await call('POST', `/api/admin/resources/${res.slug}`, values)
      : await call('PUT', `/api/admin/resources/${res.slug}/${(editing as Row).id}`, values);
    if (!r.ok) return { error: r.data.error, fields: r.data.fields };
    setEditing(null);
    flash(isNew ? 'Added.' : 'Saved.');
    load();
  };

  const remove = async (row: Row) => {
    if (!window.confirm(`Delete this ${res.singular.toLowerCase()}?\n\n“${String(row[res.titleField] ?? '').slice(0, 120)}”\n\nThis cannot be undone.`)) return;
    const r = await call('DELETE', `/api/admin/resources/${res.slug}/${row.id}`);
    if (r.ok) { flash('Deleted.'); load(); } else flash(r.data.error || 'Delete failed', false);
  };

  const toggle = async (row: Row) => {
    const r = await call('PUT', `/api/admin/resources/${res.slug}/${row.id}`, { published: !row.published });
    if (r.ok) setRows((rs) => rs.map((x) => (x.id === row.id ? { ...x, published: !row.published } : x)));
    else flash(r.data.error || 'Update failed', false);
  };

  const drop = async (targetId: number) => {
    if (dragId === null || dragId === targetId) return;
    const next = [...rows];
    const from = next.findIndex((r) => r.id === dragId);
    const to = next.findIndex((r) => r.id === targetId);
    if (from < 0 || to < 0) return;
    next.splice(to, 0, next.splice(from, 1)[0]);
    setRows(next);
    setDragId(null);
    const r = await call('POST', '/api/admin/reorder', { resource: res.slug, ids: next.map((x) => x.id) });
    flash(r.ok ? 'Order saved.' : r.data.error || 'Could not save order', r.ok);
  };

  const bulkUpload = async (files: FileList | File[]) => {
    const list = Array.from(files).filter((f) => f.type.startsWith('image/'));
    if (!list.length) return flash('Choose image files (JPG, PNG, WebP or GIF).', false);
    if (!dropCat) return flash('Pick a category first.', false);
    setUploading(true);
    let ok = 0;
    const errs: string[] = [];
    for (const f of list) {
      const u = await upload(f, 'image', 'gallery');
      if (!u.url) { errs.push(`${f.name}: ${u.error}`); continue; }
      const title = f.name.replace(/\.[a-z0-9]+$/i, '').replace(/[-_]+/g, ' ').slice(0, 120) || 'Untitled';
      const r = await call('POST', `/api/admin/resources/${res.slug}`, { title, category: dropCat, image: u.url, published: true });
      if (r.ok) ok++; else errs.push(`${f.name}: ${r.data.error || 'could not save'}`);
    }
    setUploading(false);
    flash(`${ok} image${ok === 1 ? '' : 's'} added.${errs.length ? ' ' + errs.join(' · ') : ''}`, errs.length === 0);
    load();
  };

  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">{res.label}</h1>
          <p className="text-sm text-ink-mute">{total} {total === 1 ? 'record' : 'records'}</p>
        </div>
        <div className="flex gap-2">
          {canReorder && <button className={`btn ${reorder ? 'btn-gold' : 'btn-ghost'} px-3 py-2`} onClick={() => { setReorder(!reorder); setPage(1); }}>{reorder ? 'Done reordering' : 'Reorder'}</button>}
          <a className="btn btn-ghost px-3 py-2" href={`/api/admin/export/${res.slug}`} download>Export CSV</a>
          <button className="btn btn-ghost px-3 py-2" onClick={() => setImporting(true)}>Import CSV</button>
          <button className="btn btn-primary px-4 py-2" onClick={() => setEditing('new')}>+ Add {res.singular.toLowerCase()}</button>
        </div>
      </div>

      {isGallery && (
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files?.length) bulkUpload(e.dataTransfer.files); }}
          className="mt-5 rounded-md border-2 border-dashed border-navy/25 bg-white p-5 text-center"
        >
          <p className="text-sm font-medium text-navy">{uploading ? 'Uploading…' : 'Drag & drop images here to add them to the gallery'}</p>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-3">
            <select className="field max-w-xs" value={dropCat} onChange={(e) => setDropCat(e.target.value)} aria-label="Category for new images">
              <option value="">Category for new images…</option>
              {res.fields.find((f) => f.name === 'category')?.options?.map((o) => <option key={o}>{o}</option>)}
            </select>
            <button className="btn btn-ghost px-3 py-2" disabled={uploading} onClick={() => fileRef.current?.click()}>Choose files</button>
            <input ref={fileRef} type="file" multiple accept="image/jpeg,image/png,image/webp,image/gif" className="sr-only" onChange={(e) => { if (e.target.files) bulkUpload(e.target.files); e.target.value = ''; }} />
          </div>
        </div>
      )}

      <div className="mt-5 flex flex-wrap gap-3">
        <input className="field max-w-xs" placeholder="Search…" aria-label="Search" value={typed} onChange={(e) => setTyped(e.target.value)} />
        {selects.map((f) => (
          <select key={f.name} className="field max-w-[200px]" aria-label={`Filter by ${f.label}`} value={filters[f.name] || ''} onChange={(e) => { setFilters((p) => ({ ...p, [f.name]: e.target.value })); setPage(1); }}>
            <option value="">{f.label}: all</option>
            {f.options?.map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        ))}
        {res.published && (
          <select className="field max-w-[180px]" aria-label="Filter by status" value={pub} onChange={(e) => { setPub(e.target.value); setPage(1); }}>
            <option value="">Status: all</option>
            <option value="1">Published</option>
            <option value="0">Unpublished</option>
          </select>
        )}
        {filtered && <button className="text-sm underline" onClick={() => { setTyped(''); setText(''); setFilters({}); setPub(''); setPage(1); }}>Clear filters</button>}
      </div>

      {reorder && <p className="mt-4 rounded bg-gold-100 px-3 py-2 text-sm text-gold-600">Drag a row by its handle (⠿) and drop it on another row. Order is saved automatically and applies to the public pages where they use manual order.</p>}

      <div className="card mt-5 overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="border-b border-line bg-navy-50 text-xs uppercase tracking-wide text-ink-soft">
            <tr>
              {reorder && <th className="w-8 px-2" />}
              {isGallery && <th className="w-16 px-3 py-2.5">Image</th>}
              {cols.map((c) => <th key={c.name} className="px-3 py-2.5 font-semibold">{c.label}</th>)}
              {res.published && <th className="px-3 py-2.5 font-semibold">Status</th>}
              <th className="px-3 py-2.5 text-right font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={9} className="px-3 py-8 text-center text-ink-mute">Loading…</td></tr>}
            {!loading && rows.length === 0 && <tr><td colSpan={9} className="px-3 py-8 text-center text-ink-mute">No records found.</td></tr>}
            {!loading && rows.map((r) => (
              <tr key={r.id} className={`border-b border-line last:border-0 ${dragId === r.id ? 'opacity-40' : ''}`} draggable={reorder} onDragStart={() => setDragId(r.id)} onDragOver={(e) => reorder && e.preventDefault()} onDrop={() => reorder && drop(r.id)} onDragEnd={() => setDragId(null)}>
                {reorder && <td className="cursor-grab px-2 text-ink-mute" aria-hidden>⠿</td>}
                {isGallery && (
                  <td className="px-3 py-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={r.image} alt="" className="h-10 w-14 rounded object-cover" />
                  </td>
                )}
                {cols.map((c) => (
                  <td key={c.name} className="max-w-[280px] px-3 py-2.5 align-top">
                    <span className="line-clamp-2">{c.type === 'bool' ? (r[c.name] ? '✓' : '—') : String(r[c.name] ?? '')}</span>
                  </td>
                ))}
                {res.published && (
                  <td className="px-3 py-2.5 align-top">
                    <button onClick={() => toggle(r)} className={`chip ${r.published ? 'chip-teal' : ''}`} aria-label={r.published ? 'Unpublish' : 'Publish'} title="Click to toggle">
                      {r.published ? 'Published' : 'Draft'}
                    </button>
                  </td>
                )}
                <td className="whitespace-nowrap px-3 py-2.5 text-right align-top">
                  <button className="mr-3 font-medium text-navy-600 hover:underline" onClick={() => setEditing(r)}>Edit</button>
                  <button className="font-medium text-red-700 hover:underline" onClick={() => remove(r)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pages > 1 && !reorder && (
        <div className="mt-4 flex items-center justify-between text-sm">
          <button className="btn btn-ghost px-3 py-1.5" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span className="text-ink-mute">Page {page} of {pages}</span>
          <button className="btn btn-ghost px-3 py-1.5" disabled={page >= pages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-navy/50 p-4 sm:p-8" role="dialog" aria-modal="true" aria-label={editing === 'new' ? `Add ${res.singular}` : `Edit ${res.singular}`}>
          <div className="w-full max-w-2xl rounded-md bg-white p-6 shadow-card">
            <h2 className="mb-5 text-xl font-semibold">{editing === 'new' ? `Add ${res.singular.toLowerCase()}` : `Edit ${res.singular.toLowerCase()}`}</h2>
            <RecordForm
              fields={res.fields}
              folder={res.key.replace(/_/g, '-')}
              initial={{ ...initialValues(res.fields, editing === 'new' ? null : editing), ...(res.published ? { published: editing === 'new' ? true : !!(editing as Row).published } : {}) }}
              onSubmit={save}
              onCancel={() => setEditing(null)}
              submitLabel={editing === 'new' ? 'Add' : 'Save changes'}
              withPublished={!!res.published}
            />
          </div>
        </div>
      )}

      {importing && <CsvImport res={res} onClose={() => setImporting(false)} onDone={(n) => { setImporting(false); flash(`${n} records imported.`); load(); }} />}

      {toast && <div role="status" className={`fixed bottom-5 right-5 z-[60] max-w-sm rounded-md px-4 py-3 text-sm text-white shadow-card ${toast.ok ? 'bg-teal-700' : 'bg-red-700'}`}>{toast.t}</div>}
    </div>
  );
}
