import type { Field } from '@/lib/resources';

export function initialValues(fields: Field[], row?: Record<string, any> | null) {
  const v: Record<string, any> = {};
  for (const f of fields) v[f.name] = row ? row[f.name] ?? (f.type === 'bool' ? false : '') : f.type === 'bool' ? false : '';
  return v;
}
