'use client';
import { useRef, useState } from 'react';
import type { Field } from '@/lib/resources';
import { upload } from './client';

export function FileField({ value, onChange, kind = 'image', folder }: { value: string; onChange: (v: string) => void; kind?: 'image' | 'pdf'; folder: string }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const ref = useRef<HTMLInputElement>(null);
  const pick = async (f?: File | null) => {
    if (!f) return;
    setBusy(true);
    setErr('');
    const r = await upload(f, kind, folder);
    setBusy(false);
    if (r.url) onChange(r.url);
    else setErr(r.error || 'Upload failed');
    if (ref.current) ref.current.value = '';
  };
  return (
    <div className="space-y-2">
      <div className="flex items-start gap-3">
        {kind === 'image' && value && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={value} alt="" className="h-16 w-16 shrink-0 rounded border border-line object-cover" />
        )}
        <div className="min-w-0 flex-1 space-y-2">
          <input className="field" value={value} onChange={(e) => onChange(e.target.value)} placeholder={kind === 'pdf' ? '/uploads/cv/… or https://…' : '/uploads/images/… or https://…'} />
          <div className="flex flex-wrap items-center gap-2">
            <label className="btn btn-ghost cursor-pointer px-3 py-1.5 text-xs">
              {busy ? 'Uploading…' : kind === 'pdf' ? 'Upload PDF' : 'Upload image'}
              <input ref={ref} type="file" className="sr-only" accept={kind === 'pdf' ? 'application/pdf' : 'image/jpeg,image/png,image/webp,image/gif'} disabled={busy} onChange={(e) => pick(e.target.files?.[0])} />
            </label>
            {value && <button type="button" className="text-xs text-red-700 hover:underline" onClick={() => onChange('')}>Remove</button>}
            <span className="text-xs text-ink-mute">{kind === 'pdf' ? 'PDF, up to 4 MB on Vercel' : 'JPG, PNG, WebP or GIF, up to 4 MB on Vercel'}</span>
          </div>
          {err && <p role="alert" className="text-xs text-red-700">{err}</p>}
        </div>
      </div>
    </div>
  );
}

export function FieldInput({ f, value, onChange, error, folder }: { f: Field; value: any; onChange: (v: any) => void; error?: string; folder: string }) {
  const id = `f-${f.name}`;
  let input: React.ReactNode;
  switch (f.type) {
    case 'textarea':
      input = <textarea id={id} className="field min-h-[96px]" rows={f.name === 'biography' ? 14 : f.name === 'highlights' ? 8 : 4} value={value ?? ''} onChange={(e) => onChange(e.target.value)} maxLength={f.max} />;
      break;
    case 'number':
      input = <input id={id} className="field" type="number" step="any" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
      break;
    case 'bool':
      input = (
        <label className="inline-flex items-center gap-2 text-sm">
          <input id={id} type="checkbox" className="h-4 w-4 rounded border-line text-navy" checked={!!value} onChange={(e) => onChange(e.target.checked)} /> Yes
        </label>
      );
      break;
    case 'select':
      input = (
        <select id={id} className="field" value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
          <option value="">— select —</option>
          {f.options?.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      );
      break;
    case 'image':
      input = <FileField value={value ?? ''} onChange={onChange} folder={folder} />;
      break;
    default:
      input = <input id={id} className="field" type={f.type === 'url' ? 'text' : 'text'} value={value ?? ''} onChange={(e) => onChange(e.target.value)} maxLength={f.max} />;
  }
  return (
    <div>
      <label htmlFor={id} className="label">{f.label}{f.required && <span className="text-red-700"> *</span>}</label>
      {input}
      {f.help && <p className="mt-1 text-xs text-ink-mute">{f.help}</p>}
      {error && <p role="alert" className="mt-1 text-xs font-medium text-red-700">{error}</p>}
    </div>
  );
}

export function RecordForm({
  fields, initial, folder, submitLabel = 'Save', onSubmit, onCancel, extra, withPublished,
}: {
  fields: Field[];
  initial: Record<string, any>;
  folder: string;
  submitLabel?: string;
  onSubmit: (values: Record<string, any>) => Promise<{ error?: string; fields?: Record<string, string> } | void>;
  onCancel?: () => void;
  extra?: React.ReactNode;
  withPublished?: boolean;
}) {
  const [v, setV] = useState(initial);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg('');
    setErrs({});
    const r = await onSubmit(v);
    setBusy(false);
    if (r && (r.error || r.fields)) {
      setErrs(r.fields || {});
      setMsg(r.error || 'Please fix the highlighted fields.');
    }
  };
  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {fields.map((f) => (
        <FieldInput key={f.name} f={f} value={v[f.name]} onChange={(x) => setV((p) => ({ ...p, [f.name]: x }))} error={errs[f.name]} folder={folder} />
      ))}
      {withPublished && (
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 rounded border-line" checked={!!v.published} onChange={(e) => setV((p) => ({ ...p, published: e.target.checked }))} />
          Published (visible on the public site)
        </label>
      )}
      {extra}
      {msg && <p role="alert" className="rounded border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">{msg}</p>}
      <div className="flex gap-3 pt-2">
        <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : submitLabel}</button>
        {onCancel && <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
