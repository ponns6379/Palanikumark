export async function call<T = any>(method: string, url: string, body?: unknown): Promise<{ ok: boolean; status: number; data: T & { error?: string; fields?: Record<string, string> } }> {
  try {
    const r = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
    });
    const data = await r.json().catch(() => ({}));
    if (r.status === 401 && typeof window !== 'undefined') window.location.href = '/admin/login';
    return { ok: r.ok, status: r.status, data };
  } catch {
    return { ok: false, status: 0, data: { error: 'Network error — please try again.' } as any };
  }
}

export async function upload(file: File, kind: 'image' | 'pdf', folder: string): Promise<{ url?: string; error?: string }> {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('kind', kind);
  fd.append('folder', folder);
  try {
    const r = await fetch('/api/admin/upload', { method: 'POST', body: fd, credentials: 'same-origin' });
    const d = await r.json().catch(() => ({}));
    return r.ok ? { url: d.url } : { error: d.error || 'Upload failed' };
  } catch {
    return { error: 'Network error — upload failed.' };
  }
}
