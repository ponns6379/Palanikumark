'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';

type Item = { href: string; label: string };
type Group = { label: string; items: Item[] };

const NAV: (Item | Group)[] = [
  { href: '/', label: 'Home' },
  {
    label: 'About',
    items: [
      { href: '/about', label: 'About' },
      { href: '/academic-journey', label: 'Academic Journey' },
      { href: '/memberships', label: 'Memberships' },
    ],
  },
  {
    label: 'Research',
    items: [
      { href: '/research', label: 'Research Overview' },
      { href: '/publications', label: 'Publications' },
      { href: '/patents', label: 'Patents' },
      { href: '/projects', label: 'Projects & Funding' },
      { href: '/consultancy', label: 'Consultancy' },
    ],
  },
  {
    label: 'Academia',
    items: [
      { href: '/scholars', label: 'Ph.D. Scholars' },
      { href: '/academic-contributions', label: 'Academic Contributions' },
      { href: '/awards', label: 'Awards' },
    ],
  },
  { href: '/gallery', label: 'Gallery' },
  { href: '/news', label: 'News' },
  { href: '/contact', label: 'Contact' },
];

const isGroup = (n: Item | Group): n is Group => 'items' in n;

export function Header({ name, subtitle }: { name: string; subtitle: string }) {
  const path = usePathname() || '/';
  const [open, setOpen] = useState(false);
  const [dd, setDd] = useState<string | null>(null);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    setOpen(false);
    setDd(null);
  }, [path]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setDd(null);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setDd(null);
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  const active = (href: string) => (href === '/' ? path === '/' : path === href || path.startsWith(href + '/'));
  const groupActive = (g: Group) => g.items.some((i) => active(i.href));

  return (
    <header ref={ref} className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Link href="/" className="group flex min-w-0 items-center gap-3 no-underline">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-sm bg-navy font-serif text-sm font-semibold text-white ring-1 ring-gold/60">PK</span>
          <span className="min-w-0 leading-tight">
            <span className="block truncate font-serif text-[1.05rem] font-semibold text-navy">{name}</span>
            <span className="hidden truncate text-[11px] uppercase tracking-[0.14em] text-ink-mute sm:block">{subtitle}</span>
          </span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-0.5 lg:flex">
          {NAV.map((n) =>
            isGroup(n) ? (
              <div key={n.label} className="relative">
                <button
                  type="button"
                  aria-expanded={dd === n.label}
                  aria-haspopup="true"
                  onClick={() => setDd(dd === n.label ? null : n.label)}
                  className={`flex items-center gap-1 rounded px-3 py-2 text-sm font-medium ${groupActive(n) ? 'text-navy' : 'text-ink-soft hover:text-navy'}`}
                >
                  {n.label}
                  <Icon name="chevron" className={`h-3.5 w-3.5 transition-transform ${dd === n.label ? 'rotate-180' : ''}`} />
                </button>
                {dd === n.label && (
                  <div className="absolute left-0 top-full mt-1 w-56 rounded-md border border-line bg-white py-1.5 shadow-card">
                    {n.items.map((i) => (
                      <Link key={i.href} href={i.href} className={`block px-4 py-2 text-sm no-underline hover:bg-navy-50 ${active(i.href) ? 'font-semibold text-navy' : 'text-ink-soft'}`}>
                        {i.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <Link key={n.href} href={n.href} aria-current={active(n.href) ? 'page' : undefined} className={`relative rounded px-3 py-2 text-sm font-medium no-underline ${active(n.href) ? 'text-navy' : 'text-ink-soft hover:text-navy'}`}>
                {n.label}
                {active(n.href) && <span className="absolute inset-x-3 -bottom-[13px] h-0.5 bg-gold" />}
              </Link>
            ),
          )}
        </nav>

        <button type="button" className="rounded p-2 text-navy lg:hidden" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}>
          <Icon name={open ? 'close' : 'menu'} className="h-6 w-6" />
        </button>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="max-h-[80vh] overflow-y-auto border-t border-line bg-white lg:hidden">
          <div className="container-page py-3">
            {NAV.map((n) =>
              isGroup(n) ? (
                <div key={n.label} className="py-1">
                  <p className="px-2 pt-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-gold-600">{n.label}</p>
                  {n.items.map((i) => (
                    <Link key={i.href} href={i.href} className={`block rounded px-2 py-2.5 text-[15px] no-underline ${active(i.href) ? 'bg-navy-50 font-semibold text-navy' : 'text-ink-soft'}`}>
                      {i.label}
                    </Link>
                  ))}
                </div>
              ) : (
                <Link key={n.href} href={n.href} className={`block rounded px-2 py-2.5 text-[15px] no-underline ${active(n.href) ? 'bg-navy-50 font-semibold text-navy' : 'text-ink-soft'}`}>
                  {n.label}
                </Link>
              ),
            )}
          </div>
        </nav>
      )}
    </header>
  );
}
