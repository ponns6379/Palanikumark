/** Server-rendered SVG bar chart — no client JS. Values are derived from database records. */
export function BarChart({ data, color = '#1d4e89', title, height = 180 }: { data: { label: string | number; value: number }[]; color?: string; title: string; height?: number }) {
  if (!data.length) return null;
  const max = Math.max(...data.map((d) => d.value), 1);
  const W = 640;
  const pad = { t: 18, b: 28, l: 4, r: 4 };
  const bw = (W - pad.l - pad.r) / data.length;
  const ih = height - pad.t - pad.b;
  const every = data.length > 16 ? Math.ceil(data.length / 12) : 1;
  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${height}`} role="img" aria-label={title} className="h-auto w-full">
        <title>{title}</title>
        <line x1={pad.l} x2={W - pad.r} y1={height - pad.b} y2={height - pad.b} stroke="#cfd6df" />
        {data.map((d, i) => {
          const h = (d.value / max) * ih;
          const x = pad.l + i * bw + bw * 0.14;
          const w = bw * 0.72;
          return (
            <g key={String(d.label)}>
              <rect x={x} y={height - pad.b - h} width={w} height={Math.max(h, d.value ? 1 : 0)} fill={color} rx={1.5}>
                <title>{`${d.label}: ${d.value}`}</title>
              </rect>
              {data.length <= 24 && d.value > 0 && (
                <text x={x + w / 2} y={height - pad.b - h - 4} textAnchor="middle" fontSize="10" fill="#4a5565">{d.value}</text>
              )}
              {i % every === 0 && (
                <text x={x + w / 2} y={height - 10} textAnchor="middle" fontSize="10" fill="#6b7686">{d.label}</text>
              )}
            </g>
          );
        })}
      </svg>
    </figure>
  );
}

export function HBars({ data, color = '#0F766E', suffix = '' }: { data: { label: string; value: number }[]; color?: string; suffix?: string }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <ul className="space-y-3">
      {data.map((d) => (
        <li key={String(d.label)}>
          <div className="flex items-baseline justify-between gap-3 text-sm">
            <span className="text-ink-soft">{d.label}</span>
            <span className="shrink-0 font-semibold text-navy">{d.value}{suffix}</span>
          </div>
          <div className="mt-1 h-2 overflow-hidden rounded-full bg-navy-50">
            <div className="h-full rounded-full" style={{ width: `${(d.value / max) * 100}%`, background: color }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
