import type { Metadata } from 'next';
import { Pagination } from '@/components/Pagination';
import { Empty, FilterChips, PageHeader, SearchBox, pageOf } from '@/components/ui';
import { one, q } from '@/lib/db';
import { one as first } from '@/lib/format';

export const metadata: Metadata = { title: 'Patents', description: 'Granted and published patents and designs.' };

export default async function Patents({ searchParams }: { searchParams: Promise<Record<string, string | string[]>> }) {
  const sp = await searchParams;
  const text = first(sp.q).trim().slice(0, 100);
  const status = ['Granted', 'Published', 'Filed'].includes(first(sp.status)) ? first(sp.status) : '';
  const where = ['published = true'];
  const params: any[] = [];
  if (text) { params.push(`%${text}%`); where.push(`(title ILIKE $1 OR applicants ILIKE $1 OR application_no ILIKE $1)`); }
  if (status) { params.push(status); where.push(`status = $${params.length}`); }
  const W = where.join(' AND ');
  const total = (await one<{ c: number }>(`SELECT count(*)::int AS c FROM patents WHERE ${W}`, params))?.c ?? 0;
  const { page, pages, offset, size } = pageOf(first(sp.page), total, 12);
  const [rows, counts] = await Promise.all([
    q(`SELECT * FROM patents WHERE ${W} ORDER BY (status = 'Granted') DESC, status_date_iso DESC NULLS LAST, id LIMIT ${size} OFFSET ${offset}`, params),
    q("SELECT status, count(*)::int AS c FROM patents WHERE published = true GROUP BY status"),
  ]);
  const n = (s: string) => counts.find((c) => c.status === s)?.c ?? 0;
  const all = counts.reduce((a, c) => a + c.c, 0);
  return (
    <>
      <PageHeader eyebrow="Innovation" title="Patents & designs" intro="Granted and published patents and designs, with application numbers and dates as recorded in the profile." />
      <section className="section">
        <div className="container-page">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <FilterChips base="/patents" param="status" current={status} params={{ q: text }} options={[{ value: '', label: 'All', count: all }, { value: 'Granted', label: 'Granted', count: n('Granted') }, { value: 'Published', label: 'Published', count: n('Published') }]} />
            <SearchBox action="/patents" q={text} placeholder="Search title, inventor, number…" hidden={{ status }} />
          </div>
          <p className="mt-6 text-sm text-ink-mute" aria-live="polite">{total} {total === 1 ? 'record' : 'records'}</p>
          {rows.length === 0 ? <div className="mt-4"><Empty>No patents match.</Empty></div> : (
            <ul className="mt-4 grid gap-4 md:grid-cols-2">
              {rows.map((r) => (
                <li key={r.id} className="card card-pad flex flex-col">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`chip ${r.status === 'Granted' ? 'chip-gold' : 'chip-navy'}`}>{r.status}</span>
                    {r.kind === 'Design' && <span className="chip chip-teal">Design</span>}
                    <span className="ml-auto text-xs text-ink-mute">{r.application_no}</span>
                  </div>
                  <h2 className="mt-3 font-serif text-lg font-semibold leading-snug">{r.title}</h2>
                  {r.applicants && <p className="mt-2 text-sm text-ink-soft">{r.applicants.split(';').map((s: string) => s.trim()).filter(Boolean).join(' · ')}</p>}
                  <dl className="mt-auto grid grid-cols-2 gap-3 pt-4 text-sm">
                    {r.application_date && <div><dt className="text-xs text-ink-mute">Filed</dt><dd>{r.application_date}</dd></div>}
                    {r.status_date && <div><dt className="text-xs text-ink-mute">{r.status === 'Granted' ? 'Granted' : 'Published'}</dt><dd>{r.status_date}</dd></div>}
                  </dl>
                  {r.link && <a href={r.link} target="_blank" rel="noopener noreferrer" className="mt-3 text-sm font-medium">View document</a>}
                </li>
              ))}
            </ul>
          )}
          <Pagination base="/patents" params={{ q: text, status }} page={page} pages={pages} />
        </div>
      </section>
    </>
  );
}
