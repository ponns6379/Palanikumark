import type { Metadata } from 'next';
import { Empty, FilterChips, PageHeader } from '@/components/ui';
import { q } from '@/lib/db';
import { one as first } from '@/lib/format';
import { Icon } from '@/components/Icon';

export const metadata: Metadata = { title: 'Awards & Recognition', description: 'Awards, honours, fellowships and global recognitions.' };

export default async function Awards({ searchParams }: { searchParams: Promise<Record<string, string | string[]>> }) {
  const sp = await searchParams;
  const cat = first(sp.category).slice(0, 80);
  const all = await q('SELECT * FROM awards WHERE published = true ORDER BY year DESC NULLS LAST, sort_order, id');
  const cats = Array.from(new Set(all.map((a) => a.category).filter(Boolean))) as string[];
  const rows = cat ? all.filter((a) => a.category === cat) : all;
  const groups: [string, any[]][] = [];
  for (const a of rows) {
    const k = a.year ? String(a.year) : 'Undated';
    const g = groups.find((x) => x[0] === k);
    g ? g[1].push(a) : groups.push([k, [a]]);
  }
  return (
    <>
      <PageHeader eyebrow="Recognition" title="Awards & honours" intro="A chronological record of awards, fellowships and recognitions as listed in the profile." />
      <section className="section">
        <div className="container-page">
          <FilterChips base="/awards" param="category" current={cat} params={{}} options={[{ value: '', label: 'All', count: all.length }, ...cats.map((c) => ({ value: c, label: c, count: all.filter((a) => a.category === c).length }))]} />
          {rows.length === 0 ? <div className="mt-6"><Empty /></div> : (
            <ol className="timeline mt-10">
              {groups.map(([year, items]) => (
                <li key={year} className="relative pb-10 last:pb-0">
                  <span className="timeline-dot" />
                  <h2 className="font-serif text-2xl font-semibold text-gold-600">{year}</h2>
                  <ul className="mt-3 grid gap-3 md:grid-cols-2">
                    {items.map((a) => (
                      <li key={a.id} className="card card-pad">
                        <div className="flex items-start gap-3">
                          <Icon name="award" className="mt-0.5 h-5 w-5 shrink-0 text-gold" />
                          <div>
                            <h3 className="text-base font-semibold leading-snug">{a.name}</h3>
                            {a.organization && <p className="mt-1 text-sm text-ink-soft">{a.organization}</p>}
                            {a.description && <p className="mt-1 text-sm text-ink-mute">{a.description}</p>}
                            {a.category && <span className="chip mt-2">{a.category}</span>}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ol>
          )}
        </div>
      </section>
    </>
  );
}
