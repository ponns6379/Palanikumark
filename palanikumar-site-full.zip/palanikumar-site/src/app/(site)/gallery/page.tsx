import { GalleryGrid } from '@/components/GalleryGrid';
import type { Metadata } from 'next';
import { Empty, FilterChips, PageHeader } from '@/components/ui';
import { q } from '@/lib/db';
import { one as first } from '@/lib/format';

export const metadata: Metadata = { title: 'Gallery', description: 'Photographs from academic events, conferences, awards and research.' };

export default async function Gallery({ searchParams }: { searchParams: Promise<Record<string, string | string[]>> }) {
  const sp = await searchParams;
  const cat = first(sp.category).slice(0, 80);
  const all = await q('SELECT * FROM gallery WHERE published = true ORDER BY sort_order, id');
  const cats = Array.from(new Set(all.map((g) => g.category).filter(Boolean))) as string[];
  const rows = cat ? all.filter((g) => g.category === cat) : all;
  return (
    <>
      <PageHeader eyebrow="Gallery" title="Moments & milestones" intro="Images drawn from the profile document. More can be added from the admin panel." />
      <section className="section">
        <div className="container-page">
          <FilterChips base="/gallery" param="category" current={cat} params={{}} options={[{ value: '', label: 'All', count: all.length }, ...cats.map((c) => ({ value: c, label: c, count: all.filter((g) => g.category === c).length }))]} />
          {rows.length === 0 ? <div className="mt-6"><Empty>No images in this category yet.</Empty></div> : (
            <GalleryGrid items={rows.map((g) => ({ id: g.id, title: g.title, category: g.category, image: g.image, caption: g.caption, event_name: g.event_name, event_date: g.event_date, link: g.link }))} />
          )}
        </div>
      </section>
    </>
  );
}
