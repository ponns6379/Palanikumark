import Image from 'next/image';
import type { Metadata } from 'next';
import { Empty, PageHeader, SectionHead } from '@/components/ui';
import { q } from '@/lib/db';
import { getStats } from '@/lib/queries';

export const metadata: Metadata = { title: 'Academic Contributions', description: 'Books authored and edited, book chapters, proceedings, editorial board roles and peer review.' };

const KINDS: [string, string, string][] = [
  ['authored', 'Books authored', 'Textbooks and reference books'],
  ['edited', 'Books edited', 'Edited volumes'],
  ['proceedings', 'Proceedings edited', 'Conference proceedings'],
  ['chapter', 'Book chapters', 'Chapters contributed to edited volumes'],
];

export default async function Books() {
  const [books, roles, stats] = await Promise.all([
    q('SELECT * FROM books ORDER BY year DESC NULLS LAST, sort_order, id'),
    q('SELECT * FROM editorial_roles ORDER BY sort_order, id'),
    getStats(),
  ]);
  const reviews = stats.find((s) => s.key === 'peer_reviews');
  const cats = Array.from(new Set(roles.map((r) => r.category || 'Other')));
  return (
    <>
      <PageHeader eyebrow="Books · Editorial · Peer review" title="Academic contributions" intro="Books, edited volumes and chapters, along with editorial board appointments and peer-review activity." />
      <section className="section">
        <div className="container-page space-y-16">
          {KINDS.map(([kind, title, sub]) => {
            const items = books.filter((b) => b.kind === kind);
            if (!items.length) return null;
            const grid = kind !== 'chapter';
            return (
              <div key={kind}>
                <SectionHead eyebrow={`${items.length} ${items.length === 1 ? 'entry' : 'entries'}`} title={title} intro={sub} />
                {grid ? (
                  <ul className="grid gap-4 md:grid-cols-2">
                    {items.map((b) => (
                      <li key={b.id} className="card card-pad flex gap-4">
                        {b.cover && <Image src={b.cover} alt={`Cover of ${b.title}`} width={72} height={96} className="h-24 w-[72px] shrink-0 rounded-sm border border-line object-cover" />}
                        <div>
                          <h3 className="font-serif text-lg font-semibold leading-snug">{b.title}</h3>
                          <p className="mt-1 text-sm text-ink-soft">{[b.publisher, b.year].filter(Boolean).join(' · ')}</p>
                          {b.note && <p className="mt-1 text-xs text-ink-mute">{b.note}</p>}
                          {b.doi && <a className="mt-1 inline-block text-sm" href={`https://doi.org/${b.doi}`} target="_blank" rel="noopener noreferrer">DOI</a>}
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <ol className="space-y-3">
                    {items.map((b) => (
                      <li key={b.id} className="card card-pad">
                        <h3 className="font-medium text-navy">{b.title}</h3>
                        <p className="mt-1 text-sm text-ink-soft">{b.citation}</p>
                        {b.doi && <a className="mt-1 inline-block text-sm" href={`https://doi.org/${b.doi}`} target="_blank" rel="noopener noreferrer">DOI</a>}
                      </li>
                    ))}
                  </ol>
                )}
              </div>
            );
          })}

          <div>
            <SectionHead eyebrow="Service" title="Editorial board roles" />
            {roles.length === 0 ? <Empty /> : (
              <div className="grid gap-6 md:grid-cols-2">
                {cats.map((c) => (
                  <div key={c} className="card card-pad">
                    <h3 className="text-base font-semibold text-teal">{c}</h3>
                    <ul className="mt-3 divide-y divide-line">
                      {roles.filter((r) => (r.category || 'Other') === c).map((r) => (
                        <li key={r.id} className="py-2.5 text-sm">
                          <p className="font-medium text-ink">{r.journal}</p>
                          <p className="text-ink-mute">{r.position}{r.from_year ? ` · ${r.from_year}${r.to_year ? ' – ' + r.to_year : ''}` : ''}</p>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </div>

          {reviews && (
            <div className="rounded-md border border-line bg-white p-6 sm:p-8">
              <p className="eyebrow">Peer review</p>
              <p className="mt-2 font-serif text-4xl font-semibold text-navy">{reviews.value}</p>
              <p className="mt-1 text-ink-soft">{reviews.label}</p>
              {reviews.note && <p className="mt-1 text-xs text-ink-mute">{reviews.note}</p>}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
