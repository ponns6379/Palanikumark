import type { Metadata } from 'next';
import { PageHeader, Empty } from '@/components/ui';
import { q } from '@/lib/db';

export const metadata: Metadata = { title: 'Memberships', description: 'Professional society memberships and fellowships.' };

export default async function Memberships() {
  const rows = await q('SELECT * FROM memberships ORDER BY sort_order, id');
  return (
    <>
      <PageHeader eyebrow="Professional bodies" title="Memberships" intro="Memberships and fellowships of professional societies, with membership numbers as recorded in the profile." />
      <section className="section">
        <div className="container-page">
          {rows.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {rows.map((m) => (
                <article key={m.id} className="card card-pad">
                  <h2 className="text-lg font-semibold leading-snug">{m.organization}</h2>
                  {m.membership_type && <p className="mt-1 text-sm font-medium text-teal">{m.membership_type}</p>}
                  <dl className="mt-3 space-y-1 text-sm text-ink-soft">
                    {m.membership_no && <div className="flex gap-2"><dt className="text-ink-mute">Membership no.</dt><dd>{m.membership_no}</dd></div>}
                    {m.since && <div className="flex gap-2"><dt className="text-ink-mute">Since</dt><dd>{m.since.replace(/^Since\s*/i, '')}</dd></div>}
                  </dl>
                </article>
              ))}
            </div>
          ) : <Empty />}
        </div>
      </section>
    </>
  );
}
