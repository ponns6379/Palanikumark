import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { getProfile, getSettings, getSocial } from '@/lib/queries';
import { siteUrl } from '@/lib/site';

export default async function SiteLayout({ children }: { children: React.ReactNode }) {
  const [profile, settings, social, base] = await Promise.all([getProfile(), getSettings(), getSocial(), siteUrl()]);
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: profile.full_name,
    honorificSuffix: profile.honorifics || undefined,
    jobTitle: profile.designation,
    description: profile.research_interest || undefined,
    image: `${base}${profile.photo || '/images/profile.jpg'}`,
    url: base,
    email: profile.email ? `mailto:${profile.email}` : undefined,
    worksFor: { '@type': 'CollegeOrUniversity', name: profile.institution, address: profile.location },
    knowsAbout: ['Composite materials', 'Natural fibre composites', 'Manufacturing engineering', 'Total quality management', 'Optimization'],
    sameAs: social.map((s) => s.url),
  };
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded focus:bg-navy focus:px-4 focus:py-2 focus:text-white">
        Skip to content
      </a>
      <Header name={profile.display_name || profile.full_name} subtitle={profile.designation} />
      <main id="main">{children}</main>
      <Footer profile={profile} social={social} note={settings.footer_note || ''} cv={settings.cv_url || ''} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }} />
    </>
  );
}
