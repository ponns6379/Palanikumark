import type { Metadata } from 'next';
import { PageHeader, SectionHead, Empty } from '@/components/ui';
import { q } from '@/lib/db';

export const metadata: Metadata = { title: 'Academic Journey', description: 'Qualifications and professional experience timeline.' };

export default async function Journey() {
  const [quals, exp] = await Promise.all([
    q('SELECT * FROM qualifications ORDER BY sort_order, id'),
    q('SELECT * FROM experience ORDER BY sort_order, id'),
  ]);
  const teaching = exp.filter((e) => e.kind !== 'Other experience');
  const other = exp.filter((e) => e.kind === 'Other experience');
  const Entry = ({ e }: { e: any }) => (
    <li className="relative pb-8 last:pb-0">
      <span className="timeline-dot" />
      <p className="text-xs font-semibold uppercase tracking-wider text-gold-600">
        {e.start_year}{e.start_year || e.end_year ? ' – ' : ''}{e.end_year}
      </p>
      <h3 className="mt-1 text-xl font-semibold">{e.designation}</h3>
      <p className="font-medium text-ink-soft">{e.organization}</p>
      {e.duties && <p className="mt-1.5 text-sm text-ink-soft">{e.duties}</p>}
      {e.reason_for_leaving && <p className="mt-1 text-xs text-ink-mute">{e.reason_for_leaving}</p>}
    </li>
  );
  return (
    <>
      <PageHeader eyebrow="Academic journey" title="From the shop floor to the principal's office" intro="Qualifications and professional experience, as recorded in the profile." />
      <section className="section">
        <div className="container-page grid gap-14 lg:grid-cols-2">
          <div>
            <SectionHead eyebrow="Education" title="Qualifications" />
            {quals.length ? (
              <ol className="timeline">
                {quals.map((x) => (
                  <li key={x.id} className="relative pb-8 last:pb-0">
                    <span className="timeline-dot" />
                    {x.year && <p className="text-xs font-semibold uppercase tracking-wider text-gold-600">{x.year}</p>}
                    <h3 className="mt-1 text-xl font-semibold">{x.degree}</h3>
                    <p className="text-ink-soft">{x.institution}</p>
                    {x.note && <p className="mt-1 text-sm text-ink-soft">{x.note}</p>}
                    {x.highlight && <span className="chip chip-gold mt-2">Distinction</span>}
                  </li>
                ))}
              </ol>
            ) : <Empty />}
          </div>
          <div>
            <SectionHead eyebrow="Experience" title="Teaching, research & administration" />
            {teaching.length ? <ol className="timeline">{teaching.map((e) => <Entry key={e.id} e={e} />)}</ol> : <Empty />}
            {other.length > 0 && (
              <div className="mt-12">
                <p className="eyebrow mb-4">Other experience</p>
                <ol className="timeline">{other.map((e) => <Entry key={e.id} e={e} />)}</ol>
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
