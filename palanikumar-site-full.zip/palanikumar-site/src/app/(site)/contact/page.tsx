import type { Metadata } from 'next';
import { Icon } from '@/components/Icon';
import { PageHeader } from '@/components/ui';
import { getProfile, getSettings, getSocial } from '@/lib/queries';

export const metadata: Metadata = { title: 'Contact', description: 'Contact details for Dr. K. Palani Kumar.' };

export default async function Contact() {
  const [p, s, social] = await Promise.all([getProfile(), getSettings(), getSocial()]);
  const Card = ({ icon, title, children }: { icon: string; title: string; children: React.ReactNode }) => (
    <div className="card card-pad">
      <span className="flex h-10 w-10 items-center justify-center rounded bg-navy-50 text-navy"><Icon name={icon} /></span>
      <h2 className="mt-4 text-lg font-semibold">{title}</h2>
      <div className="mt-1.5 space-y-1 text-sm text-ink-soft">{children}</div>
    </div>
  );
  return (
    <>
      <PageHeader eyebrow="Contact" title="Get in touch" intro="For research collaboration, consultancy, academic and institutional enquiries." />
      <section className="section">
        <div className="container-page grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          <Card icon="mail" title="Email">
            {p.email && <p><a href={`mailto:${p.email}`} className="break-all">{p.email}</a></p>}
            {p.alt_email && <p><a href={`mailto:${p.alt_email}`} className="break-all">{p.alt_email}</a></p>}
          </Card>
          <Card icon="pin" title="Institution">
            <p className="font-medium text-ink">{p.designation}</p>
            <p>{p.institution}</p>
            <p>{p.location}</p>
          </Card>
          <Card icon="link" title="Professional profiles">
            {social.map((x) => (
              <p key={x.id}><a href={x.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1">{x.platform}<Icon name="external" className="h-3.5 w-3.5" /></a></p>
            ))}
          </Card>
          {s.cv_url && (
            <div className="md:col-span-2 lg:col-span-3">
              <a href={s.cv_url} download className="btn btn-gold"><Icon name="download" className="h-4 w-4" />Download full profile (PDF)</a>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
