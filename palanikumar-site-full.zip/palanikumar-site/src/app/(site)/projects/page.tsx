import type { Metadata } from 'next';
import { Empty, PageHeader, SectionHead } from '@/components/ui';
import { one, q } from '@/lib/db';
import { getStats } from '@/lib/queries';

export const metadata: Metadata = { title: 'Projects & Funding', description: 'Externally funded research and development projects.' };

export default async function Projects() {
  const [rows, tot, stats] = await Promise.all([
    q('SELECT * FROM projects WHERE published = true ORDER BY source_no DESC NULLS LAST, id'),
    one<{ lakhs: number; n: number }>('SELECT coalesce(sum(amount_lakhs),0)::float AS lakhs, count(amount_lakhs)::int AS n FROM projects WHERE published = true'),
    getStats(),
  ]);
  const stated = stats.find((s) => s.key === 'funding');
  const lakhs = tot?.lakhs ?? 0;
  return (
    <>
      <PageHeader eyebrow="Funding" title="Projects & funding" intro="Externally funded projects with agency and amount as written in the profile." />
      <section className="section">
        <div className="container-page">
          <div className="grid gap-4 md:grid-cols-3">
            {stated && (
              <div className="rounded-md bg-navy p-6 text-white md:col-span-1">
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gold">Total funding (as stated)</p>
                <p className="mt-3 font-serif text-5xl font-semibold text-white">{stated.value}</p>
                <p className="mt-2 text-sm text-white/70">{stated.note || 'As stated in the profile'}</p>
              </div>
            )}
            <div className="card card-pad">
              <p className="eyebrow">Sum of listed amounts</p>
              <p className="mt-3 font-serif text-4xl font-semibold text-navy">{lakhs.toLocaleString('en-IN', { maximumFractionDigits: 2 })} <span className="text-lg text-ink-mute">lakhs</span></p>
              <p className="mt-2 text-xs text-ink-mute">Added up from the {tot?.n ?? 0} projects below that state an amount. Shown separately from the stated total.</p>
            </div>
            <div className="card card-pad">
              <p className="eyebrow">Projects listed</p>
              <p className="mt-3 font-serif text-4xl font-semibold text-teal">{rows.length}</p>
              <p className="mt-2 text-xs text-ink-mute">Sponsored, funded and ongoing.</p>
            </div>
          </div>

          <div className="mt-12">
            <SectionHead eyebrow="Projects" title="Funded projects" />
            {rows.length === 0 ? <Empty /> : (
              <ul className="space-y-3">
                {rows.map((r) => (
                  <li key={r.id} className="card card-pad grid gap-3 md:grid-cols-[1fr_auto] md:items-start">
                    <div>
                      <h3 className="font-serif text-lg font-semibold leading-snug">{r.title}</h3>
                      <p className="mt-1 text-sm text-ink-soft">{r.agency}</p>
                      <p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-mute">
                        {r.duration && <span>Duration: {r.duration}</span>}
                        {r.start_date && <span>Start: {r.start_date}</span>}
                        {r.end_date && <span>End: {r.end_date}</span>}
                        {r.grant_no && <span>Ref: {r.grant_no}</span>}
                        {r.role && <span>Role: {r.role}</span>}
                        {r.status && <span>{r.status}</span>}
                      </p>
                    </div>
                    {r.amount && <p className="rounded bg-gold-100 px-3 py-1.5 font-serif text-lg font-semibold text-gold-600">{r.amount}</p>}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
