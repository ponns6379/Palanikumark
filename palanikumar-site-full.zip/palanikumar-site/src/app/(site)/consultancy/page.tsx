import type { Metadata } from 'next';
import { Empty, PageHeader } from '@/components/ui';
import { q } from '@/lib/db';

export const metadata: Metadata = { title: 'Consultancy', description: 'Industry consultancy and applied projects.' };

export default async function Consultancy() {
  const rows = await q('SELECT * FROM consultancy WHERE published = true ORDER BY sort_order, id');
  return (
    <>
      <PageHeader eyebrow="Industry" title="Consultancy" intro="Consultancy and applied work for industry and government undertakings, as recorded in the profile." />
      <section className="section">
        <div className="container-page">
          {rows.length === 0 ? <Empty /> : (
            <ul className="grid gap-4 md:grid-cols-2">
              {rows.map((r) => (
                <li key={r.id} className="card card-pad">
                  <h2 className="font-serif text-lg font-semibold leading-snug">{r.title}</h2>
                  {r.client && <p className="mt-1 text-sm font-medium text-ink-soft">{r.client}</p>}
                  {r.description && <p className="mt-2 text-sm text-ink-soft">{r.description}</p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {r.period && <span className="chip">{r.period}</span>}
                    {r.amount && <span className="chip chip-gold">{r.amount}</span>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </>
  );
}
