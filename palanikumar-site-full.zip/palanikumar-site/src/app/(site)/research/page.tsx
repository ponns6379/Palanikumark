import Link from 'next/link';
import type { Metadata } from 'next';
import { BarChart, HBars } from '@/components/Charts';
import { Icon } from '@/components/Icon';
import { PageHeader, SectionHead, Stat } from '@/components/ui';
import { q, one } from '@/lib/db';
import { getImpactChains } from '@/lib/impact';
import { getStats } from '@/lib/queries';

export const metadata: Metadata = { title: 'Research', description: 'Research interests, indexed output statistics and the research-to-impact pipeline.' };

export default async function Research() {
  const [interests, stats, byYear, pByYear, byAgency, chains, c] = await Promise.all([
    q('SELECT * FROM research_interests ORDER BY sort_order, id'),
    getStats(),
    q('SELECT year::int AS label, count(*)::int AS value FROM publications WHERE published = true AND year >= 2000 GROUP BY year ORDER BY year'),
    q("SELECT left(coalesce(status_date_iso, application_date_iso),4) AS label, count(*)::int AS value FROM patents WHERE published = true AND coalesce(status_date_iso, application_date_iso) IS NOT NULL GROUP BY 1 ORDER BY 1"),
    q("SELECT agency AS label, sum(amount_lakhs)::float AS value FROM projects WHERE published = true AND amount_lakhs IS NOT NULL AND agency <> '' GROUP BY agency ORDER BY value DESC LIMIT 8"),
    getImpactChains(),
    one<any>(`SELECT
      (SELECT count(*)::int FROM research_interests) AS interests,
      (SELECT count(*)::int FROM publications WHERE published = true) AS pubs,
      (SELECT count(*)::int FROM patents WHERE published = true) AS patents,
      (SELECT count(*)::int FROM projects WHERE published = true) AS projects,
      (SELECT count(*)::int FROM consultancy WHERE published = true) AS consult`),
  ]);
  const k = Object.fromEntries(stats.map((s) => [s.key, s]));
  const block = (keys: string[]) => keys.map((x) => k[x]).filter(Boolean);
  const scopus = block(['scopus_articles', 'scopus_citations', 'scopus_h']);
  const gs = block(['gs_articles', 'gs_citations', 'gs_h']);
  const rest = block(['patents', 'funding', 'peer_reviews', 'scholars', 'awards_count', 'projects_count', 'editorial_count']);

  const flow = [
    { icon: 'flask', label: 'Research', n: c.interests, sub: 'focus areas' },
    { icon: 'book', label: 'Publications', n: c.pubs, sub: 'records listed' },
    { icon: 'bulb', label: 'Patents', n: c.patents, sub: 'granted & published' },
    { icon: 'cog', label: 'Application', n: c.projects + c.consult, sub: 'funded & consultancy projects' },
    { icon: 'check', label: 'Impact', n: chains.length, sub: 'patent → industry matches' },
  ];

  return (
    <>
      <PageHeader eyebrow="Research" title="Composite materials, manufacturing and optimization" intro="Research interests, indexed publication statistics, and how research connects to patents, funded projects and industry work." />

      <section className="section">
        <div className="container-page">
          <SectionHead eyebrow="Interests" title="Research areas" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {interests.map((r) => (
              <article key={r.id} className="card card-pad">
                <span className="flex h-11 w-11 items-center justify-center rounded bg-teal-100 text-teal"><Icon name={r.icon || 'layers'} className="h-6 w-6" /></span>
                <h3 className="mt-4 text-lg font-semibold">{r.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{r.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section border-y border-line bg-white">
        <div className="container-page">
          <SectionHead eyebrow="Dashboard" title="Research statistics" intro="The profile states two sets of publication metrics based on different indexes. They are shown separately and are not combined or reconciled." />
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h3 className="mb-3 flex items-center gap-2 text-base font-semibold"><span className="chip chip-navy">Scopus / Web of Science</span></h3>
              <div className="grid grid-cols-3 gap-3">{scopus.map((s) => <Stat key={s.key} value={s.value} label={s.label.replace('Scopus ', '').replace('Scopus/WoS-indexed ', '')} />)}</div>
              <p className="mt-2 text-xs text-ink-mute">As stated in the profile for Scopus/WoS-indexed articles.</p>
            </div>
            <div>
              <h3 className="mb-3 flex items-center gap-2 text-base font-semibold"><span className="chip chip-gold">Scopus / WoS / Google Scholar</span></h3>
              <div className="grid grid-cols-3 gap-3">{gs.map((s) => <Stat key={s.key} tone="gold" value={s.value} label={s.label.replace(/^(Google Scholar|GS)\s*/i, '')} />)}</div>
              <p className="mt-2 text-xs text-ink-mute">As stated in the profile for the combined Scopus/WoS/Google Scholar set.</p>
            </div>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
            {rest.map((s, i) => <Stat key={s.key} tone={i % 2 ? 'teal' : 'navy'} value={s.value} label={s.label} note={s.live ? 'Counted live from this site’s records' : s.note} />)}
          </div>
          <p className="mt-5 max-w-3xl text-xs leading-relaxed text-ink-mute">
            The <Link href="/publications">Publications</Link> page lists {c.pubs} unique records compiled from the profile’s separate lists (Scopus/WoS, Google Scholar and other). That list length is a compilation count and is not meant to equal either stated total above.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-page grid gap-8 lg:grid-cols-2">
          <div className="card card-pad">
            <h3 className="text-lg font-semibold">Publications by year</h3>
            <p className="mb-3 text-xs text-ink-mute">Derived from records listed on this site (2000 onward).</p>
            <BarChart data={byYear.map((r) => ({ label: String(r.label), value: Number(r.value) }))} title="Publications per year" />
          </div>
          <div className="card card-pad">
            <h3 className="text-lg font-semibold">Patents by year</h3>
            <p className="mb-3 text-xs text-ink-mute">Grant or publication year; falls back to filing year.</p>
            <BarChart data={pByYear.map((r) => ({ label: String(r.label), value: Number(r.value) }))} color="#B8892B" title="Patents per year" />
          </div>
          {byAgency.length > 0 && (
            <div className="card card-pad lg:col-span-2">
              <h3 className="text-lg font-semibold">Funding by agency</h3>
              <p className="mb-4 text-xs text-ink-mute">Sum of project amounts (in lakhs) where an amount is stated.</p>
              <HBars data={byAgency.map((a) => ({ label: a.label, value: Math.round(a.value * 100) / 100 }))} suffix=" lakhs" />
            </div>
          )}
        </div>
      </section>

      <section className="section border-t border-line bg-white">
        <div className="container-page">
          <SectionHead eyebrow="Pipeline" title="Research → Innovation → Patent → Application → Impact" intro="How the record connects. Counts come from the records on this site." />
          <ol className="grid gap-3 md:grid-cols-5">
            {flow.map((f, i) => (
              <li key={f.label} className="relative rounded-md border border-line bg-paper p-5">
                <Icon name={f.icon} className="h-6 w-6 text-gold" />
                <p className="mt-3 font-serif text-3xl font-semibold text-navy">{f.n}</p>
                <p className="font-semibold text-ink">{f.label}</p>
                <p className="text-xs text-ink-mute">{f.sub}</p>
                {i < flow.length - 1 && <span className="absolute -right-3 top-1/2 z-10 hidden -translate-y-1/2 text-gold md:block"><Icon name="arrow" className="h-5 w-5" /></span>}
              </li>
            ))}
          </ol>
          {chains.length > 0 && (
            <div className="mt-10">
              <h3 className="text-xl font-semibold">Patents that reached industry work</h3>
              <p className="mt-1 text-sm text-ink-soft">Shown only where a patent title and a consultancy project title in the profile match.</p>
              <ul className="mt-5 space-y-3">
                {chains.map((ch) => (
                  <li key={ch.patent.id} className="card card-pad grid gap-3 md:grid-cols-[1fr_auto_1fr] md:items-center">
                    <div><span className="chip chip-gold">Patent · {ch.patent.status}</span><p className="mt-2 font-medium text-navy">{ch.patent.title}</p><p className="text-xs text-ink-mute">{ch.patent.application_no}</p></div>
                    <Icon name="arrow" className="hidden h-5 w-5 text-gold md:block" />
                    <div><span className="chip chip-teal">Consultancy / application</span>{ch.work.map((w) => <p key={w.id} className="mt-2 text-sm text-ink-soft">{w.title}{w.client ? ` — ${w.client}` : ''}{w.period ? ` (${w.period})` : ''}</p>)}</div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
