import Image from 'next/image';
import Link from 'next/link';
import type { Metadata } from 'next';
import { Icon } from '@/components/Icon';
import { PageHeader } from '@/components/ui';
import { getProfile, getSettings } from '@/lib/queries';
import { lines, paragraphs } from '@/lib/format';

export const metadata: Metadata = { title: 'About', description: 'Biography, qualifications and professional highlights of Dr. K. Palani Kumar.' };

export default async function About() {
  const [p, s] = await Promise.all([getProfile(), getSettings()]);
  const facts: [string, string][] = [
    ['Designation', p.designation],
    ['Institution', p.institution],
    ['Location', p.location],
    ['Qualification', p.honorifics],
    ['Specialization', p.specialization],
  ].filter(([, v]) => v) as [string, string][];
  return (
    <>
      <PageHeader eyebrow="About" title={p.full_name} intro={p.tagline} />
      <section className="section">
        <div className="container-page grid gap-12 lg:grid-cols-[320px_1fr]">
          <aside className="space-y-6">
            <div className="overflow-hidden rounded-md border border-line bg-white shadow-card">
              <Image src={p.photo || '/images/profile.jpg'} alt={`Portrait of ${p.full_name}`} width={640} height={800} className="h-auto w-full" />
            </div>
            <dl className="card card-pad space-y-3 text-sm">
              {facts.map(([k, v]) => (
                <div key={k}>
                  <dt className="eyebrow">{k}</dt>
                  <dd className="mt-0.5 text-ink">{v}</dd>
                </div>
              ))}
            </dl>
            {s.cv_url && (
              <a href={s.cv_url} download className="btn btn-gold w-full"><Icon name="download" className="h-4 w-4" />Download CV / Profile</a>
            )}
          </aside>
          <div>
            <div className="prose-bio">
              {paragraphs(p.biography).map((t, i) => <p key={i}>{t}</p>)}
            </div>
            {lines(p.highlights).length > 0 && (
              <div className="mt-10">
                <p className="eyebrow">Professional highlights</p>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {lines(p.highlights).map((h, i) => (
                    <li key={i} className="flex gap-3 rounded-md border border-line bg-white p-4 text-sm leading-relaxed text-ink-soft">
                      <Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-teal" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <div className="mt-10 flex flex-wrap gap-3">
              <Link href="/academic-journey" className="btn btn-primary">Academic journey</Link>
              <Link href="/research" className="btn btn-ghost">Research</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
