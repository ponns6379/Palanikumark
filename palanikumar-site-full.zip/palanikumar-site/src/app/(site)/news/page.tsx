import type { Metadata } from 'next';
import { Pagination } from '@/components/Pagination';
import { Empty, FilterChips, PageHeader, pageOf } from '@/components/ui';
import { one, q } from '@/lib/db';
import { fmtDate, one as first } from '@/lib/format';

export const metadata: Metadata = { title: 'News & Updates', description: 'Latest news, patents, awards and academic updates.' };

export default async function News({ searchParams }: { searchParams: Promise<Record<string, string | string[]>> }) {
  const sp = await searchParams;
  const cat = first(sp.category).slice(0, 80);
  const where = ['published = true'];
  const params: any[] = [];
  if (cat) { params.push(cat); where.push('category = $1'); }
  const W = where.join(' AND ');
  const total = (await one<{ c: number }>(`SELECT count(*)::int AS c FROM news WHERE ${W}`, params))?.c ?? 0;
  const { page, pages, offset, size } = pageOf(first(sp.page), total, 10);
  const [rows, cats] = await Promise.all([
    q(`SELECT * FROM news WHERE ${W} ORDER BY date DESC, id DESC LIMIT ${size} OFFSET ${offset}`, params),
    q('SELECT category, count(*)::int AS c FROM news WHERE published = true AND category <> \'\' GROUP BY category ORDER BY category'),
  ]);
  const all = cats.reduce((a, c) => a + c.c, 0);
  return (
    <>
      <PageHeader eyebrow="News" title="News & updates" intro="Recent patents, awards, publications and academic activity." />
      <section className="section">
        <div className="container-page max-w-4xl">
          <FilterChips base="/news" param="category" current={cat} params={{}} options={[{ value: '', label: 'All', count: all }, ...cats.map((c) => ({ value: c.category, label: c.category, count: c.c }))]} />
          {rows.length === 0 ? <div className="mt-6"><Empty>No updates yet.</Empty></div> : (
            <ul className="mt-8 space-y-4">
              {rows.map((n) => (
                <li key={n.id} className="card card-pad">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <time dateTime={n.date} className="font-semibold text-gold-600">{fmtDate(n.date)}</time>
                    {n.category && <span className="chip chip-teal">{n.category}</span>}
                  </div>
                  <h2 className="mt-2 font-serif text-xl font-semibold leading-snug">{n.title}</h2>
                  {n.summary && <p className="mt-1.5 text-ink-soft">{n.summary}</p>}
                  {n.link && <a href={n.link} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-sm font-medium">Read more</a>}
                </li>
              ))}
            </ul>
          )}
          <Pagination base="/news" params={{ category: cat }} page={page} pages={pages} />
        </div>
      </section>
    </>
  );
}
