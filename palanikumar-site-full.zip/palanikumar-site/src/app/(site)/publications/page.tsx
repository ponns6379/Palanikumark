import Link from 'next/link';
import type { Metadata } from 'next';
import { Pagination } from '@/components/Pagination';
import { Empty, FilterChips, PageHeader, pageOf } from '@/components/ui';
import { Icon } from '@/components/Icon';
import { one, q } from '@/lib/db';
import { one as first } from '@/lib/format';

export const metadata: Metadata = { title: 'Publications', description: 'Searchable list of journal articles, with Scopus, Web of Science and Google Scholar indexing flags.' };

const SOURCES: Record<string, string> = { scopus: 'scopus = true', wos: 'wos = true', gs: 'google_scholar = true' };

export default async function Publications({ searchParams }: { searchParams: Promise<Record<string, string | string[]>> }) {
  const sp = await searchParams;
  const text = first(sp.q).trim().slice(0, 100);
  const source = SOURCES[first(sp.source)] ? first(sp.source) : '';
  const year = /^\d{4}$/.test(first(sp.year)) ? first(sp.year) : '';
  const journal = first(sp.journal).slice(0, 200);

  const where = ['published = true'];
  const params: any[] = [];
  if (text) {
    params.push(`%${text}%`);
    where.push(`(title ILIKE $${params.length} OR authors ILIKE $${params.length} OR journal ILIKE $${params.length} OR doi ILIKE $${params.length} OR keywords ILIKE $${params.length})`);
  }
  if (source) where.push(SOURCES[source]);
  if (year) { params.push(Number(year)); where.push(`year = $${params.length}`); }
  if (journal) { params.push(journal); where.push(`journal = $${params.length}`); }
  const W = where.join(' AND ');

  const total = (await one<{ c: number }>(`SELECT count(*)::int AS c FROM publications WHERE ${W}`, params))?.c ?? 0;
  const { page, pages, offset, size } = pageOf(first(sp.page), total);
  const [rows, years, journals, counts] = await Promise.all([
    q(`SELECT * FROM publications WHERE ${W} ORDER BY year DESC NULLS LAST, id LIMIT ${size} OFFSET ${offset}`, params),
    q('SELECT year::int AS y FROM publications WHERE published = true AND year IS NOT NULL GROUP BY year ORDER BY year DESC'),
    q("SELECT journal AS j, count(*)::int AS c FROM publications WHERE published = true AND journal <> '' GROUP BY journal ORDER BY c DESC, journal LIMIT 80"),
    one<any>(`SELECT count(*)::int AS total, count(*) FILTER (WHERE scopus)::int AS scopus, count(*) FILTER (WHERE wos)::int AS wos, count(*) FILTER (WHERE google_scholar)::int AS gs FROM publications WHERE published = true`),
  ]);
  const base: Record<string, string | undefined> = { q: text, source, year, journal };

  return (
    <>
      <PageHeader eyebrow="Publications" title="Journal articles & papers" intro={<>Records compiled from the profile’s Scopus/WoS, Google Scholar and other lists, merged by DOI and title so each paper appears once. Indexing badges reflect the list(s) a paper appeared in.</>} />
      <section className="section">
        <div className="container-page">
          <form method="get" action="/publications" className="card card-pad grid gap-3 md:grid-cols-[1.4fr_1fr_1fr_auto] md:items-end" role="search">
            {source && <input type="hidden" name="source" value={source} />}
            <div>
              <label htmlFor="pq" className="label">Search</label>
              <div className="relative">
                <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
                <input id="pq" name="q" defaultValue={text} placeholder="Title, author, journal, DOI…" className="field pl-9" />
              </div>
            </div>
            <div>
              <label htmlFor="py" className="label">Year</label>
              <select id="py" name="year" defaultValue={year} className="field">
                <option value="">All years</option>
                {years.map((y) => <option key={y.y} value={y.y}>{y.y}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="pj" className="label">Journal</label>
              <select id="pj" name="journal" defaultValue={journal} className="field">
                <option value="">All journals</option>
                {journals.map((j) => <option key={j.j} value={j.j}>{j.j} ({j.c})</option>)}
              </select>
            </div>
            <div className="flex gap-2">
              <button className="btn btn-primary">Apply</button>
              <Link href="/publications" className="btn btn-ghost">Reset</Link>
            </div>
          </form>

          <div className="mt-5">
            <FilterChips
              base="/publications"
              param="source"
              current={source}
              params={{ q: text, year, journal }}
              options={[
                { value: '', label: 'All', count: counts.total },
                { value: 'scopus', label: 'Scopus', count: counts.scopus },
                { value: 'wos', label: 'Web of Science', count: counts.wos },
                { value: 'gs', label: 'Google Scholar', count: counts.gs },
              ]}
            />
          </div>

          <p className="mt-6 text-sm text-ink-mute" aria-live="polite">{total} {total === 1 ? 'record' : 'records'}{total > 0 && pages > 1 ? ` · page ${page} of ${pages}` : ''}</p>

          {rows.length === 0 ? (
            <div className="mt-4"><Empty>No publications match these filters.</Empty></div>
          ) : (
            <ol className="mt-4 space-y-3" start={offset + 1}>
              {rows.map((r) => (
                <li key={r.id} className="card card-pad">
                  <h2 className="font-serif text-[1.05rem] font-semibold leading-snug text-navy">{r.title}</h2>
                  {r.authors && <p className="mt-1.5 text-sm text-ink-soft">{r.authors}</p>}
                  <p className="mt-1 text-sm text-ink-mute">
                    <span className="font-medium text-ink-soft">{r.journal}</span>
                    {r.year ? ` · ${r.year}` : ''}
                    {r.volume ? ` · Vol. ${r.volume}` : ''}
                    {r.issue ? ` (${r.issue})` : ''}
                    {r.pages ? ` · pp. ${r.pages}` : ''}
                  </p>
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {r.scopus && <span className="chip chip-navy">Scopus</span>}
                    {r.wos && <span className="chip chip-teal">Web of Science</span>}
                    {r.google_scholar && <span className="chip chip-gold">Google Scholar</span>}
                    {r.citations != null && <span className="chip">{r.citations} citations</span>}
                    {(r.url || r.doi) && (
                      <a href={r.url || `https://doi.org/${r.doi}`} target="_blank" rel="noopener noreferrer" className="ml-auto inline-flex items-center gap-1 text-sm font-medium">
                        {r.doi ? 'DOI' : 'View'} <Icon name="external" className="h-3.5 w-3.5" />
                      </a>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          )}
          <Pagination base="/publications" params={base} page={page} pages={pages} />
        </div>
      </section>
    </>
  );
}
