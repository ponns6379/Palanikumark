import type { Metadata } from 'next';
import { Empty, FilterChips, PageHeader, SearchBox } from '@/components/ui';
import { q } from '@/lib/db';
import { initials, one as first } from '@/lib/format';

export const metadata: Metadata = { title: 'Ph.D. Scholars', description: 'Doctoral scholars supervised, with research titles and completion dates.' };

export default async function Scholars({ searchParams }: { searchParams: Promise<Record<string, string | string[]>> }) {
  const sp = await searchParams;
  const text = first(sp.q).trim().slice(0, 100);
  const area = first(sp.area).slice(0, 100);
  const all = await q('SELECT * FROM scholars WHERE published = true ORDER BY completion_year DESC NULLS LAST, id');
  const areas = Array.from(new Set(all.map((s) => s.area).filter(Boolean))) as string[];
  const t = text.toLowerCase();
  const rows = all.filter((s) => (!area || s.area === area) && (!t || `${s.name} ${s.title} ${s.university}`.toLowerCase().includes(t)));
  return (
    <>
      <PageHeader eyebrow="Mentoring" title="Ph.D. scholars" intro={`${all.length} doctoral scholars guided, with research titles as listed in the profile. Research-area tags are a convenience grouping assigned from the thesis title.`} />
      <section className="section">
        <div className="container-page">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <FilterChips base="/scholars" param="area" current={area} params={{ q: text }} options={[{ value: '', label: 'All', count: all.length }, ...areas.map((a) => ({ value: a, label: a, count: all.filter((s) => s.area === a).length }))]} />
            <SearchBox action="/scholars" q={text} placeholder="Search scholar or topic…" hidden={{ area }} />
          </div>
          <p className="mt-6 text-sm text-ink-mute" aria-live="polite">{rows.length} {rows.length === 1 ? 'scholar' : 'scholars'}</p>
          {rows.length === 0 ? <div className="mt-4"><Empty>No scholars match.</Empty></div> : (
            <ul className="mt-4 grid gap-4 md:grid-cols-2">
              {rows.map((s) => (
                <li key={s.id} className="card card-pad flex gap-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-navy font-serif text-sm font-semibold text-white" aria-hidden>{initials(s.name)}</span>
                  <div className="min-w-0">
                    <h2 className="text-lg font-semibold">{s.name}</h2>
                    <p className="mt-1 text-sm leading-relaxed text-ink-soft">{s.title}</p>
                    <p className="mt-2 text-xs text-ink-mute">{[s.university, s.completion].filter(Boolean).join(' · ')}</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {s.role && <span className="chip chip-navy">{s.role}</span>}
                      {s.area && <span className="chip chip-teal">{s.area}</span>}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </>
  );
}
