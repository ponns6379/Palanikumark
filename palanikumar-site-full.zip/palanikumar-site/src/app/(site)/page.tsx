import Image from 'next/image';
import Link from 'next/link';
import { Icon } from '@/components/Icon';
import { SectionHead, Stat } from '@/components/ui';
import { getProfile, getSettings, getStats } from '@/lib/queries';
import { q } from '@/lib/db';
import { fmtDate } from '@/lib/format';

const HOME_STATS = ['scopus_articles', 'scopus_citations', 'scopus_h', 'patents', 'funding', 'scholars', 'peer_reviews'];

export default async function Home() {
  const [p, s, stats, interests, pubs, awards, news, badges, patents, gallery] = await Promise.all([
    getProfile(),
    getSettings(),
    getStats(),
    q('SELECT * FROM research_interests ORDER BY sort_order, id'),
    q('SELECT * FROM publications WHERE published = true AND year IS NOT NULL ORDER BY featured DESC, year DESC, id LIMIT 4'),
    q('SELECT * FROM awards WHERE published = true AND year IS NOT NULL ORDER BY featured DESC, year DESC, sort_order LIMIT 4'),
    q('SELECT * FROM news WHERE published = true ORDER BY date DESC, id DESC LIMIT 4'),
    q("SELECT * FROM awards WHERE published = true AND (category IN ('Global Recognition','National Award') OR name ILIKE 'World top 1%%%') ORDER BY featured DESC, year DESC NULLS LAST LIMIT 12"),
    q("SELECT * FROM patents WHERE published = true ORDER BY featured DESC, (status = 'Granted') DESC, status_date_iso DESC NULLS LAST LIMIT 3"),
    q("SELECT * FROM gallery WHERE published = true ORDER BY sort_order, id LIMIT 4"),
  ]);
  const byKey = Object.fromEntries(stats.map((x) => [x.key, x]));
  const shown = HOME_STATS.map((k) => byKey[k]).filter(Boolean);
  // de-duplicate repeated peer-review badges (same name in several years)
  const seen = new Set<string>();
  const badgeList = badges.filter((b) => (seen.has(b.name) ? false : (seen.add(b.name), true))).slice(0, 4);

  return (
    <>
      <section className="precision-grid relative overflow-hidden border-b border-line bg-gradient-to-b from-white via-paper to-paper">
        <div className="container-page grid items-center gap-10 py-12 sm:py-16 lg:grid-cols-[1.15fr_0.85fr] lg:py-20">
          <div>
            <p className="eyebrow">{p.designation} · {p.institution}</p>
            <h1 className="mt-3 text-4xl font-semibold leading-[1.1] sm:text-5xl lg:text-[3.4rem]">
              {p.full_name}
            </h1>
            <p className="mt-2 font-serif text-lg text-ink-mute">{p.honorifics}</p>
            <p className="lead mt-5 max-w-xl">{p.tagline}</p>
            <p className="mt-4 max-w-xl text-ink-soft">{p.research_interest}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/about" className="btn btn-primary">Explore Academic Profile <Icon name="arrow" className="h-4 w-4" /></Link>
              <Link href="/publications" className="btn btn-ghost">View Research Publications</Link>
              {s.cv_url && (
                <a href={s.cv_url} className="btn btn-gold" download>
                  <Icon name="download" className="h-4 w-4" /> Download CV
                </a>
              )}
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-3 translate-x-3 translate-y-3 rounded-md border border-gold/50" aria-hidden />
            <div className="relative overflow-hidden rounded-md bg-navy-50 shadow-card">
              <Image src={p.photo || '/images/profile.jpg'} alt={`Portrait of ${p.full_name}`} width={640} height={800} priority className="h-auto w-full object-cover" />
            </div>
            <div className="relative mt-5 rounded-md border border-line bg-white px-4 py-3 text-sm shadow-card">
              <p className="font-semibold text-navy">{p.designation}</p>
              <p className="text-ink-soft">{p.institution}</p>
              <p className="inline-flex items-center gap-1 text-ink-mute"><Icon name="pin" className="h-3.5 w-3.5" />{p.location}</p>
            </div>
          </div>
        </div>
      </section>

      {shown.length > 0 && (
        <section className="section pb-6" aria-label="Research at a glance">
          <div className="container-page">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {shown.map((x, i) => (
                <Stat key={x.key} value={x.value} label={x.label} note={x.note} tone={i % 3 === 1 ? 'teal' : i % 3 === 2 ? 'gold' : 'navy'} />
              ))}
            </div>
            <p className="mt-4 text-xs text-ink-mute">
              Figures are reproduced as stated in the profile. Google Scholar figures (a broader index) are shown separately on the <Link href="/research">Research</Link> page.
            </p>
          </div>
        </section>
      )}

      {badgeList.length > 0 && (
        <section className="section pt-8" aria-labelledby="recog">
          <div className="container-page">
            <SectionHead eyebrow="Recognition" title="Distinctions" href="/awards" cta="All awards" />
            <h3 id="recog" className="sr-only">Recognition highlights</h3>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {badgeList.map((b) => (
                <div key={b.id} className="card card-pad border-t-2 border-t-gold">
                  <Icon name="award" className="h-6 w-6 text-gold" />
                  <p className="mt-3 font-serif text-lg font-semibold leading-snug text-navy">{b.name}</p>
                  <p className="mt-1 text-sm text-ink-soft">{b.organization}</p>
                  {b.year && <p className="mt-2 text-xs font-semibold text-gold-600">{b.year}</p>}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {interests.length > 0 && (
        <section className="section border-y border-line bg-white" aria-label="Research interests">
          <div className="container-page">
            <SectionHead eyebrow="Research" title="Where the work is focused" href="/research" cta="Research overview" />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {interests.slice(0, 4).map((r) => (
                <div key={r.id} className="rounded-md border border-line p-5">
                  <span className="flex h-10 w-10 items-center justify-center rounded bg-teal-100 text-teal"><Icon name={r.icon || 'layers'} /></span>
                  <h3 className="mt-4 text-lg font-semibold">{r.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{r.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="section">
        <div className="container-page grid gap-12 lg:grid-cols-2">
          <div>
            <SectionHead eyebrow="Latest research" title="Recent publications" href="/publications" />
            <ul className="space-y-4">
              {pubs.map((x) => (
                <li key={x.id} className="card card-pad">
                  <p className="font-serif text-[1.05rem] font-semibold leading-snug text-navy">{x.url ? <a href={x.url} target="_blank" rel="noopener noreferrer" className="text-navy no-underline hover:underline">{x.title}</a> : x.title}</p>
                  <p className="mt-1.5 text-sm text-ink-soft">{x.journal} · {x.year}</p>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SectionHead eyebrow="Latest" title="Achievements & updates" href="/news" />
            <ul className="space-y-4">
              {news.map((n) => (
                <li key={n.id} className="flex gap-4 border-b border-line pb-4 last:border-0">
                  <div className="w-16 shrink-0 text-center">
                    <p className="font-serif text-2xl font-semibold leading-none text-navy">{fmtDate(n.date).split(' ')[0]}</p>
                    <p className="text-[11px] uppercase tracking-wider text-ink-mute">{fmtDate(n.date).split(' ').slice(1).join(' ')}</p>
                  </div>
                  <div>
                    <span className="chip chip-teal">{n.category}</span>
                    <p className="mt-1 font-medium text-ink">{n.title}</p>
                    {n.summary && <p className="text-sm text-ink-soft">{n.summary}</p>}
                  </div>
                </li>
              ))}
            </ul>
            {awards.length > 0 && (
              <p className="mt-6 text-sm text-ink-soft">
                Latest awards: {awards.map((a) => `${a.name} (${a.year})`).join(' · ')}
              </p>
            )}
          </div>
        </div>
      </section>

      {patents.length > 0 && (
        <section className="section border-t border-line bg-white" aria-label="Featured innovations">
          <div className="container-page">
            <SectionHead eyebrow="Innovation" title="Patents & innovation" href="/patents" cta="Full patent portfolio" />
            <div className="grid gap-4 md:grid-cols-3">
              {patents.map((x) => (
                <article key={x.id} className="rounded-md border border-line p-5">
                  <span className={`chip ${x.status === 'Granted' ? 'chip-gold' : 'chip-navy'}`}>{x.status}</span>
                  <h3 className="mt-3 font-serif text-lg font-semibold leading-snug">{x.title}</h3>
                  <p className="mt-2 text-xs text-ink-mute">{x.application_no}{x.status_date ? ` · ${x.status_date}` : ''}</p>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      {gallery.length > 0 && (
        <section className="section" aria-label="Gallery preview">
          <div className="container-page">
            <SectionHead eyebrow="Gallery" title="Moments & milestones" href="/gallery" cta="Open gallery" />
            <ul className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {gallery.map((g) => (
                <li key={g.id} className="overflow-hidden rounded-md border border-line bg-white">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={g.image} alt={g.caption || g.title} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <section className="bg-navy py-14 text-white">
        <div className="container-page flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <h2 className="font-serif text-2xl text-white sm:text-3xl">Collaborate on research, innovation or academic programmes</h2>
            <p className="mt-2 text-white/70">Reach out for research collaboration, consultancy and academic enquiries.</p>
          </div>
          <Link href="/contact" className="btn btn-gold shrink-0">Get in touch</Link>
        </div>
      </section>
    </>
  );
}
