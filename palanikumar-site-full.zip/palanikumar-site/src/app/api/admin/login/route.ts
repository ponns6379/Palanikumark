import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { json } from '@/lib/api';
import { audit, clearRate, clientIp, createSession, rateLimited } from '@/lib/auth';
import { one, q } from '@/lib/db';
import { supabaseAuthEnabled, supabasePasswordLogin } from '@/lib/supabase';

export const dynamic = 'force-dynamic';

// A real bcrypt hash, created once: unknown e-mails then take as long to check as known ones.
let dummyHash: string | null = null;
const getDummy = () => (dummyHash ??= bcrypt.hashSync(`dummy-${Math.random()}`, 12));

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const p = z.object({ email: z.string().email().max(200), password: z.string().min(1).max(200) }).safeParse(body);
  if (!p.success) return json({ error: 'Enter a valid e-mail and password.' }, 400);
  const email = p.data.email.toLowerCase();
  const key = `${await clientIp()}|${email}`;
  if (rateLimited(key)) return json({ error: 'Too many attempts. Please wait 15 minutes and try again.' }, 429);

  const bad = async () => {
    await audit(email, 'login_failed');
    return json({ error: 'Incorrect e-mail or password.' }, 401);
  };
  type U = { id: number; email: string; name: string; password_hash: string };
  const user = await one<U>('SELECT id, email, name, password_hash FROM admin_users WHERE email = $1', [email]);

  if (supabaseAuthEnabled()) {
    // Supabase Auth verifies the credentials; the admin_users allow-list decides who may enter /admin.
    const r = await supabasePasswordLogin(email, p.data.password);
    if (!r.ok && r.reason === 'unavailable') return json({ error: 'Sign-in service unavailable. Please try again shortly.' }, 503);
    if (!r.ok || !user) return bad();
  } else {
    const ok = await bcrypt.compare(p.data.password, user?.password_hash || getDummy());
    if (!user || !ok || !user.password_hash) return bad();
  }
  clearRate(key);
  await createSession({ id: user.id, email: user.email, name: user.name });
  await q('UPDATE admin_users SET last_login_at = now() WHERE id = $1', [user.id]);
  await audit(user.email, 'login');
  return json({ ok: true });
}
