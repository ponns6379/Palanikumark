import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { one } from '@/lib/db';
import { BY_SLUG, RESOURCES } from '@/lib/resources';
import { parseInput } from '@/lib/validate';

export const dynamic = 'force-dynamic';

const resolve = (p: string) => BY_SLUG[p] ?? RESOURCES[p];
type Ctx = { params: Promise<{ resource: string; id: string }> };

async function load(ctx: Ctx) {
  const { resource, id } = await ctx.params;
  const res = resolve(resource);
  const n = Number(id);
  if (!res || !Number.isInteger(n)) return null;
  return { res, id: n };
}

export async function GET(_req: Request, ctx: Ctx) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const t = await load(ctx);
  if (!t) return json({ error: 'Not found' }, 404);
  const row = await one(`SELECT * FROM ${t.res.key} WHERE id = $1`, [t.id]);
  return row ? json({ row }) : json({ error: 'Not found' }, 404);
}

export async function PUT(req: Request, ctx: Ctx) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const t = await load(ctx);
  if (!t) return json({ error: 'Not found' }, 404);
  const body = await req.json().catch(() => null);
  const r = parseInput(t.res, body, 'update');
  if (!r.ok) return json({ error: 'Validation failed', fields: r.errors }, 422);
  const cols = Object.keys(r.data);
  if (!cols.length) return json({ error: 'Nothing to update' }, 400);
  const row = await one(
    `UPDATE ${t.res.key} SET ${cols.map((c, i) => `${c} = $${i + 1}`).join(', ')}, updated_at = now() WHERE id = $${cols.length + 1} RETURNING *`,
    [...cols.map((c) => r.data[c]), t.id],
  );
  if (!row) return json({ error: 'Not found' }, 404);
  await audit(a.session.email, 'update', t.res.key, t.id, String(row[t.res.titleField] ?? ''));
  return json({ row });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const t = await load(ctx);
  if (!t) return json({ error: 'Not found' }, 404);
  const row = await one(`DELETE FROM ${t.res.key} WHERE id = $1 RETURNING *`, [t.id]);
  if (!row) return json({ error: 'Not found' }, 404);
  await audit(a.session.email, 'delete', t.res.key, t.id, String(row[t.res.titleField] ?? ''));
  return json({ ok: true });
}
