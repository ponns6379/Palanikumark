import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { q, one } from '@/lib/db';
import { BY_SLUG, RESOURCES } from '@/lib/resources';
import { parseInput } from '@/lib/validate';

export const dynamic = 'force-dynamic';

const resolve = (p: string) => BY_SLUG[p] ?? RESOURCES[p];

export async function GET(req: Request, ctx: { params: Promise<{ resource: string }> }) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const res = resolve((await ctx.params).resource);
  if (!res) return json({ error: 'Unknown resource' }, 404);

  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get('page')) || 1);
  const pageSize = Math.min(100, Math.max(5, Number(url.searchParams.get('pageSize')) || 25));
  const params: any[] = [];
  const where: string[] = [];

  const text = (url.searchParams.get('q') || '').trim().slice(0, 100);
  if (text) {
    params.push(`%${text}%`);
    const searchable = res.fields.filter((f) => f.search).map((f) => `${f.name} ILIKE $${params.length}`);
    if (searchable.length) where.push(`(${searchable.join(' OR ')})`);
  }
  for (const f of res.fields) {
    if (f.type === 'select') {
      const v = url.searchParams.get(`f_${f.name}`);
      if (v) { params.push(v); where.push(`${f.name} = $${params.length}`); }
    }
  }
  const pub = url.searchParams.get('published');
  if (res.published && (pub === '1' || pub === '0')) where.push(`published = ${pub === '1' ? 'true' : 'false'}`);

  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = (await one<{ c: number }>(`SELECT count(*)::int AS c FROM ${res.key} ${w}`, params))?.c ?? 0;
  const rows = await q(`SELECT * FROM ${res.key} ${w} ORDER BY ${res.order} LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`, params);
  return json({ rows, total, page, pageSize });
}

export async function POST(req: Request, ctx: { params: Promise<{ resource: string }> }) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const res = resolve((await ctx.params).resource);
  if (!res) return json({ error: 'Unknown resource' }, 404);

  const body = await req.json().catch(() => null);
  const r = parseInput(res, body, 'create');
  if (!r.ok) return json({ error: 'Validation failed', fields: r.errors }, 422);
  const data = r.data;
  if (res.published && data.published === undefined) data.published = true;
  if (res.sortable && data.sort_order === undefined) {
    data.sort_order = ((await one<{ m: number | null }>(`SELECT max(sort_order) AS m FROM ${res.key}`))?.m ?? -1) + 1;
  }
  const cols = Object.keys(data);
  const row = await one(`INSERT INTO ${res.key} (${cols.join(',')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(',')}) RETURNING *`, cols.map((c) => data[c]));
  await audit(a.session.email, 'create', res.key, row?.id, String(data[res.titleField] ?? ''));
  return json({ row }, 201);
}
