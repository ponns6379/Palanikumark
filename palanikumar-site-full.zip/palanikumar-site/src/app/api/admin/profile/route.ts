import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { one } from '@/lib/db';
import { PROFILE_FIELDS } from '@/lib/resources';
import { parseInput } from '@/lib/validate';

export const dynamic = 'force-dynamic';

export async function GET() {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  return json({ row: await one('SELECT * FROM profile WHERE id = 1') });
}

export async function PUT(req: Request) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const body = await req.json().catch(() => null);
  const r = parseInput({ fields: PROFILE_FIELDS }, body, 'update');
  if (!r.ok) return json({ error: 'Validation failed', fields: r.errors }, 422);
  const cols = Object.keys(r.data);
  if (!cols.length) return json({ error: 'Nothing to update' }, 400);
  const row = await one(`UPDATE profile SET ${cols.map((c, i) => `${c} = $${i + 1}`).join(', ')}, updated_at = now() WHERE id = 1 RETURNING *`, cols.map((c) => r.data[c]));
  await audit(a.session.email, 'update', 'profile', 1, cols.join(','));
  return json({ row });
}
