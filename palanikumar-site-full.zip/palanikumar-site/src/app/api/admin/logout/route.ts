import { json } from '@/lib/api';
import { audit, destroySession, getSession } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST() {
  const s = await getSession();
  await destroySession();
  if (s) await audit(s.email, 'logout');
  return json({ ok: true });
}
