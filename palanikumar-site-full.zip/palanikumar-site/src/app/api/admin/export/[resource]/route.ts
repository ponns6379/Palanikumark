import { requireAdmin, json } from '@/lib/api';
import { audit } from '@/lib/auth';
import { toCSV } from '@/lib/csv';
import { q } from '@/lib/db';
import { BY_SLUG, RESOURCES } from '@/lib/resources';

export const dynamic = 'force-dynamic';

/** GET /api/admin/export/<resource>            → all records as CSV
 *  GET /api/admin/export/<resource>?template=1 → header row only (import template) */
export async function GET(req: Request, ctx: { params: Promise<{ resource: string }> }) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const slug = (await ctx.params).resource;
  const res = BY_SLUG[slug] ?? RESOURCES[slug];
  if (!res) return json({ error: 'Unknown resource' }, 404);
  const header = [...res.fields.map((f) => f.name), ...(res.published ? ['published'] : [])];
  const template = new URL(req.url).searchParams.get('template') === '1';
  const rows = template ? [] : await q(`SELECT * FROM ${res.key} ORDER BY ${res.order}`);
  const body = toCSV(header, rows.map((r) => header.map((h) => r[h])));
  if (!template) await audit(a.session.email, 'export', res.key, '', `${rows.length} rows`);
  return new Response('﻿' + body, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${res.slug}${template ? '-template' : ''}.csv"`,
      'Cache-Control': 'no-store',
    },
  });
}
