import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { q } from '@/lib/db';
import { SETTING_KEYS } from '@/lib/resources';
import { parseInput } from '@/lib/validate';

export const dynamic = 'force-dynamic';

export async function GET() {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const rows = await q<{ key: string; value: string }>('SELECT key, value FROM site_settings');
  return json({ settings: Object.fromEntries(rows.map((r) => [r.key, r.value])) });
}

export async function PUT(req: Request) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const body = await req.json().catch(() => null);
  const fields = SETTING_KEYS.map((s) => ({ name: s.key, label: s.label, type: s.type }));
  const r = parseInput({ fields }, body, 'update');
  if (!r.ok) return json({ error: 'Validation failed', fields: r.errors }, 422);
  for (const [key, value] of Object.entries(r.data)) {
    await q('INSERT INTO site_settings (key, value, updated_at) VALUES ($1,$2,now()) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()', [key, String(value)]);
  }
  await audit(a.session.email, 'update', 'site_settings', '', Object.keys(r.data).join(','));
  return json({ ok: true });
}
