import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { saveUpload, UploadError, type UploadKind } from '@/lib/storage';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  try {
    const form = await req.formData();
    const file = form.get('file');
    const kind = (form.get('kind') === 'pdf' ? 'pdf' : 'image') as UploadKind;
    const folder = String(form.get('folder') || (kind === 'pdf' ? 'cv' : 'images'));
    if (!(file instanceof File)) return json({ error: 'No file received' }, 400);
    const url = await saveUpload(file, kind, folder);
    await audit(a.session.email, 'upload', folder, '', url);
    return json({ url });
  } catch (e) {
    if (e instanceof UploadError) return json({ error: e.message }, 400);
    console.error('upload failed', e);
    return json({ error: 'Upload failed' }, 500);
  }
}
