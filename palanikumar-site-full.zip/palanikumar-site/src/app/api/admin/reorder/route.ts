import { z } from 'zod';
import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { q } from '@/lib/db';
import { BY_SLUG, RESOURCES } from '@/lib/resources';

export const dynamic = 'force-dynamic';

/** Saves a drag-and-drop order: ids[] in their new display order. */
export async function POST(req: Request) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const p = z.object({ resource: z.string(), ids: z.array(z.number().int()).max(2000) }).safeParse(await req.json().catch(() => null));
  if (!p.success) return json({ error: 'Invalid request' }, 400);
  const res = BY_SLUG[p.data.resource] ?? RESOURCES[p.data.resource];
  if (!res?.sortable) return json({ error: 'This list cannot be re-ordered' }, 400);
  for (let i = 0; i < p.data.ids.length; i++) await q(`UPDATE ${res.key} SET sort_order = $1 WHERE id = $2`, [i, p.data.ids[i]]);
  await audit(a.session.email, 'reorder', res.key, '', `${p.data.ids.length} items`);
  return json({ ok: true });
}
