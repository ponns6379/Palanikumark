import { json, requireAdmin } from '@/lib/api';
import { audit } from '@/lib/auth';
import { parseCSV, unguard } from '@/lib/csv';
import { one } from '@/lib/db';
import { BY_SLUG, RESOURCES } from '@/lib/resources';
import { parseInput } from '@/lib/validate';

export const dynamic = 'force-dynamic';

const MAX_ROWS = 2000;
const TRUE = new Set(['true', 'yes', 'y', '1', 'on', 'x']);

/** POST { csv: string }               → dry run: validates every row, returns row-level errors
 *  POST { csv: string, commit: true } → inserts all rows (only if every row is valid) */
export async function POST(req: Request, ctx: { params: Promise<{ resource: string }> }) {
  const a = await requireAdmin();
  if ('error' in a) return a.error;
  const slug = (await ctx.params).resource;
  const res = BY_SLUG[slug] ?? RESOURCES[slug];
  if (!res) return json({ error: 'Unknown resource' }, 404);

  const body = await req.json().catch(() => null);
  if (!body || typeof body.csv !== 'string' || body.csv.length > 3_000_000) return json({ error: 'Send the CSV text (max 3 MB).' }, 400);

  const table = parseCSV(body.csv);
  if (table.length < 2) return json({ error: 'The file needs a header row and at least one data row.' }, 400);
  if (table.length - 1 > MAX_ROWS) return json({ error: `Too many rows (max ${MAX_ROWS} per import).` }, 400);

  const header = table[0].map((h) => h.trim());
  const known = new Set([...res.fields.map((f) => f.name), ...(res.published ? ['published'] : [])]);
  const unknown = header.filter((h) => h && !known.has(h));
  const missing = res.fields.filter((f) => f.required && !header.includes(f.name)).map((f) => f.name);
  if (missing.length) return json({ error: `Missing required column(s): ${missing.join(', ')}`, unknown }, 422);

  const errors: { row: number; errors: Record<string, string> }[] = [];
  const valid: Record<string, any>[] = [];
  table.slice(1).forEach((cells, i) => {
    const raw: Record<string, any> = {};
    header.forEach((h, c) => {
      if (!known.has(h)) return;
      let v: any = unguard((cells[c] ?? '').trim());
      const f = res.fields.find((x) => x.name === h);
      if (f?.type === 'bool' || h === 'published') v = TRUE.has(String(v).toLowerCase());
      raw[h] = v;
    });
    const r = parseInput(res, raw, 'create');
    if (r.ok) {
      const d = r.data;
      if (res.published) d.published = 'published' in raw ? !!raw.published : true;
      valid.push(d);
    } else errors.push({ row: i + 2, errors: r.errors }); // +2 = spreadsheet row number (header is row 1)
  });

  const summary = { total: table.length - 1, valid: valid.length, invalid: errors.length, unknownColumns: unknown, errors: errors.slice(0, 50) };
  if (!body.commit) return json({ ...summary, committed: false });
  if (errors.length) return json({ ...summary, committed: false, error: 'Fix the errors in the file first — nothing was imported.' }, 422);

  let order = res.sortable ? ((await one<{ m: number | null }>(`SELECT max(sort_order) AS m FROM ${res.key}`))?.m ?? -1) + 1 : 0;
  for (const d of valid) {
    if (res.sortable) d.sort_order = order++;
    const cols = Object.keys(d);
    await one(`INSERT INTO ${res.key} (${cols.join(',')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(',')})`, cols.map((c) => d[c]));
  }
  await audit(a.session.email, 'import', res.key, '', `${valid.length} rows`);
  return json({ ...summary, committed: true, imported: valid.length });
}
