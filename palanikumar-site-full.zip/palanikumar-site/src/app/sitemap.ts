import type { MetadataRoute } from 'next';
import { siteUrl } from '@/lib/site';

export const dynamic = 'force-dynamic';

const PAGES = ['', '/about', '/academic-journey', '/research', '/publications', '/patents', '/projects', '/scholars', '/awards', '/academic-contributions', '/memberships', '/consultancy', '/gallery', '/news', '/contact'];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = await siteUrl();
  return PAGES.map((p) => ({ url: `${base}${p}`, lastModified: new Date(), changeFrequency: p === '' || p === '/news' ? 'weekly' : 'monthly', priority: p === '' ? 1 : 0.7 }));
}
