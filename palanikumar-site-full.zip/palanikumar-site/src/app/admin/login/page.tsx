import { redirect } from 'next/navigation';
import { LoginForm } from '@/components/admin/LoginForm';
import { getSession } from '@/lib/auth';
import { one } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function Login({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  if (await getSession()) redirect('/admin');
  const { next = '/admin' } = await searchParams;
  const hasAdmin = ((await one<{ c: number }>('SELECT count(*)::int AS c FROM admin_users'))?.c ?? 0) > 0;
  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-6 text-center">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-sm bg-navy font-serif text-lg font-semibold text-white ring-1 ring-gold/60">PK</span>
          <h1 className="mt-4 text-2xl font-semibold">Admin sign-in</h1>
          <p className="mt-1 text-sm text-ink-mute">Authorised users only</p>
        </div>
        <div className="card card-pad">
          {hasAdmin ? (
            <LoginForm next={next} />
          ) : (
            <div className="space-y-3 text-sm text-ink-soft">
              <p className="font-semibold text-navy">No administrator exists yet.</p>
              <p>Create one from the server terminal:</p>
              <pre className="overflow-x-auto rounded bg-navy-50 p-3 text-xs text-navy">npm run create-admin</pre>
              <p>Then reload this page.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
