import { notFound } from 'next/navigation';
import { ResourceManager } from '@/components/admin/ResourceManager';
import { BY_SLUG } from '@/lib/resources';

export default async function ResourcePage({ params }: { params: Promise<{ resource: string }> }) {
  const res = BY_SLUG[(await params).resource];
  if (!res) notFound();
  return <ResourceManager key={res.key} res={res} />;
}
