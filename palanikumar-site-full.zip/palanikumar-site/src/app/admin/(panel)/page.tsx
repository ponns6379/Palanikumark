import Link from 'next/link';
import { q } from '@/lib/db';
import { getCounts } from '@/lib/queries';
import { RESOURCES } from '@/lib/resources';

export default async function Dashboard() {
  const [counts, log] = await Promise.all([
    getCounts(),
    q('SELECT * FROM audit_log ORDER BY id DESC LIMIT 12'),
  ]);
  const weakSecret = process.env.NODE_ENV === 'production' && (process.env.AUTH_SECRET || '').length < 32;
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <p className="text-sm text-ink-mute">Live counts from the database.</p>
      </div>
      {weakSecret && <p role="alert" className="rounded border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">AUTH_SECRET is missing or shorter than 32 characters. Set a long random value in the server environment.</p>}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {counts.map((c) => {
          const slug = RESOURCES[c.key]?.slug ?? c.key;
          return (
            <Link key={c.key} href={`/admin/${slug}`} className="card card-pad no-underline transition-shadow hover:shadow-md">
              <p className="font-serif text-3xl font-semibold text-navy">{c.count}</p>
              <p className="mt-1 text-sm text-ink-soft">{c.label}</p>
            </Link>
          );
        })}
      </div>
      <div className="card card-pad">
        <h2 className="text-lg font-semibold">Recent activity</h2>
        {log.length === 0 ? <p className="mt-3 text-sm text-ink-mute">No activity recorded yet.</p> : (
          <ul className="mt-3 divide-y divide-line text-sm">
            {log.map((l) => (
              <li key={l.id} className="flex flex-wrap gap-x-3 py-2">
                <span className="w-40 shrink-0 text-xs text-ink-mute">{new Date(l.created_at).toLocaleString('en-IN')}</span>
                <span className="font-medium">{l.user_email}</span>
                <span className="text-ink-soft">{l.action}{l.resource ? ` · ${l.resource}` : ''}{l.record_id ? ` #${l.record_id}` : ''}</span>
                {l.detail && <span className="min-w-0 truncate text-ink-mute">{l.detail}</span>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
