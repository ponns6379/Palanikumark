import { SettingsForm } from '@/components/admin/SingletonForms';
import { getSettings } from '@/lib/queries';
import { SETTING_KEYS } from '@/lib/resources';

export default async function SettingsPage() {
  const s = await getSettings();
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold">Settings & CV</h1>
      <p className="mb-6 text-sm text-ink-mute">Search-engine title and description, public URL, footer text and the downloadable CV.</p>
      <div className="card card-pad">
        <SettingsForm keys={SETTING_KEYS} initial={Object.fromEntries(SETTING_KEYS.map((k) => [k.key, s[k.key] ?? '']))} />
      </div>
    </div>
  );
}
