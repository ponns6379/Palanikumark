import { ProfileForm } from '@/components/admin/SingletonForms';
import { initialValues } from '@/components/admin/values';
import { getProfile } from '@/lib/queries';
import { PROFILE_FIELDS } from '@/lib/resources';

export default async function ProfilePage() {
  const p = await getProfile();
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold">Profile & biography</h1>
      <p className="mb-6 text-sm text-ink-mute">Name, designation, contact details, portrait, biography and highlights.</p>
      <div className="card card-pad">
        <ProfileForm fields={PROFILE_FIELDS} initial={initialValues(PROFILE_FIELDS, p)} />
      </div>
    </div>
  );
}
