import { redirect } from 'next/navigation';
import { AdminShell } from '@/components/admin/AdminShell';
import { getSession } from '@/lib/auth';
import { RESOURCE_LIST } from '@/lib/resources';

export const dynamic = 'force-dynamic';

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session) redirect('/admin/login');
  const r = (slug: string) => {
    const x = RESOURCE_LIST.find((y) => y.slug === slug)!;
    return { href: `/admin/${x.slug}`, label: x.label };
  };
  const groups = [
    { title: 'Overview', items: [{ href: '/admin', label: 'Dashboard' }] },
    { title: 'Site', items: [{ href: '/admin/profile', label: 'Profile & biography' }, { href: '/admin/settings', label: 'Settings & CV' }, r('statistics'), r('social')] },
    { title: 'Academic', items: [r('qualifications'), r('experience'), r('research-interests'), r('memberships')] },
    { title: 'Research output', items: [r('publications'), r('patents'), r('projects'), r('consultancy'), r('books'), r('editorial')] },
    { title: 'People & recognition', items: [r('scholars'), r('awards')] },
    { title: 'Media', items: [r('gallery'), r('news')] },
  ];
  return (
    <AdminShell user={{ name: session.name, email: session.email }} groups={groups}>
      {children}
    </AdminShell>
  );
}
