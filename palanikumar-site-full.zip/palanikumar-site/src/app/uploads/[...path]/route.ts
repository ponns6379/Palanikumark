import fs from 'node:fs';
import path from 'node:path';
import { MIME_BY_EXT, UPLOAD_DIR } from '@/lib/storage';

export const dynamic = 'force-dynamic';

/** Serves files saved to the local upload directory (when Supabase Storage is not configured). */
export async function GET(_req: Request, ctx: { params: Promise<{ path: string[] }> }) {
  const { path: parts } = await ctx.params;
  if (!parts?.length || parts.some((p) => p.includes('..') || p.includes('\\') || p.startsWith('.'))) return new Response('Not found', { status: 404 });
  const file = path.resolve(UPLOAD_DIR, ...parts);
  if (!file.startsWith(UPLOAD_DIR + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return new Response('Not found', { status: 404 });
  const ext = path.extname(file).slice(1).toLowerCase();
  const type = MIME_BY_EXT[ext];
  if (!type) return new Response('Not found', { status: 404 });
  const data = fs.readFileSync(file);
  return new Response(new Uint8Array(data), {
    headers: { 'Content-Type': type, 'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline' },
  });
}
