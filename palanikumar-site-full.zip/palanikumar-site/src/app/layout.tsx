import './globals.css';
import type { Metadata, Viewport } from 'next';
import { getProfile, getSettings } from '@/lib/queries';
import { siteUrl } from '@/lib/site';

export const dynamic = 'force-dynamic';

export const viewport: Viewport = { themeColor: '#0B2545', width: 'device-width', initialScale: 1 };

export async function generateMetadata(): Promise<Metadata> {
  const [s, p, base] = await Promise.all([getSettings(), getProfile(), siteUrl()]);
  const title = s.site_title || `${p.full_name} | ${p.designation}`;
  const description = s.site_description || '';
  return {
    metadataBase: new URL(base),
    title: { default: title, template: `%s | ${p.display_name || p.full_name}` },
    description,
    alternates: { canonical: '/' },
    openGraph: {
      type: 'profile',
      title,
      description,
      siteName: p.full_name,
      url: base,
      images: [{ url: p.photo || '/images/profile.jpg', alt: p.full_name }],
    },
    twitter: { card: 'summary', title, description, images: [p.photo || '/images/profile.jpg'] },
    robots: { index: true, follow: true },
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN">
      <body>{children}</body>
    </html>
  );
}
